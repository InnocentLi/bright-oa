package com.reborn.ec.service;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.reborn.ec.i18n.LocalLanguage;

@Service
public class EmailService {

    private final Logger logger = LogManager.getLogger(EmailService.class);
    private final LocalLanguage messageSource;
    private final MailSender mailSender;

    @Autowired
    public EmailService(LocalLanguage messageSource, MailSender mailSender) {
        this.messageSource = messageSource;
        this.mailSender = mailSender;
    }


    public void send(String email, String subject, String body) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("deri-info@fu-ling.net");
        message.setTo(email);
        message.setSubject(subject);
        message.setText(body);
        try {
            logger.info("send email to {} with subject {} and body {}", email, subject, body);
            mailSender.send(message);
        } catch (Exception e) {

            logger.error(e.getMessage());
            throw e;
        }
    }

    public void sendPasswordResetEmail(String email,  String newPassword, String lang) {
//        String baseUrl = ServletUriComponentsBuilder.fromCurrentContextPath().build().toUriString();
//        String appUrl = baseUrl + "/reset-password/" + token;
        String subject = messageSource.getMessageStr(lang,"password.reset");
        String body = messageSource.getMessageStr(lang,"password.reset") + ": " + newPassword;

        try {
            this.send(email, subject, body);
        } catch (Exception e) {
            throw e;
        }
    }


}
