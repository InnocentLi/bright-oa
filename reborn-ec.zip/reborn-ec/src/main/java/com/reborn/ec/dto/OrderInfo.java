package com.reborn.ec.dto;

import java.util.List;

import lombok.Data;

@Data
public class OrderInfo {
    private List<OrderItem> orderItems;
    private String addressId;
    private String shopId;
    private String deliveryTime;
    private String payMethod;
}
