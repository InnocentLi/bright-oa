package com.reborn.ec.model;


import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@DynamicUpdate(true)
@Table(name = "image", schema = "rebornecdb")
public class Image {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator="system-uuid")
    @GenericGenerator(name="system-uuid", strategy = "uuid")
    private String id;

    @Basic
    @Column(name = "owner_id")
    private String ownerId;

    @Basic
    @Column(name = "url")
    private String url;


}
