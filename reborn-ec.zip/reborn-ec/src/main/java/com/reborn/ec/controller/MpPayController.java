package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.ChangePasswordDto;
import com.reborn.ec.dto.ResetPasswordDto;
import com.reborn.ec.dto.SignupUser;
import com.reborn.ec.dto.UpdatePasswordDto;
import com.reborn.ec.model.User;
import com.reborn.ec.service.MpPayService;
import com.reborn.ec.service.UserService;

@RestController
public class MpPayController {

  private final MpPayService service;

  @Autowired
  public MpPayController(MpPayService service) {
    this.service = service;
  }

  @PostMapping("/mppay/notification")
  public BaseResponse<User> mpPayNotification(@RequestHeader HttpHeaders header,@RequestBody String notification) {
    return service.mpPayNotification(header/* 后面追加其请求参数 */,notification);
  }

  

}
