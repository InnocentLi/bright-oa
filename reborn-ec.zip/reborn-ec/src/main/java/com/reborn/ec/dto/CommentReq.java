package com.reborn.ec.dto;

import lombok.Data;

@Data
public class CommentReq {
    String productID;
    String productName;
    String commentContent;
}
