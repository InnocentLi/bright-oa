package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.FAQ;

import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Repository
public interface FAQRepository extends JpaRepository<FAQ, String> {

    @Query("SELECT f FROM FAQ f WHERE f.deleteFlag = 0")
    List<FAQ> findAll();
    
    @Query(value="SELECT f FROM FAQ f WHERE f.question like %:question% AND f.deleteFlag = 0")
    List<FAQ> findByQuestionLike(String question);
}
