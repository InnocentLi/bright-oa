package com.reborn.ec.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reborn.ec.constant.PaymentStatus;
import com.reborn.ec.model.Payment;
import com.reborn.ec.repository.PaymentRepository;

@Service
public class PaymentService {
    private final Logger logger = LogManager.getLogger(this.getClass());
    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public String createPayment() {
        // TODO
        Payment payment = new Payment();
        payment.setProviderId("VISA");
        payment.setStatusCode(PaymentStatus.CREATED.getByteValue());
        paymentRepository.save(payment);
        logger.info("Payment created: " + payment.getId());
        return paymentRepository.save(payment).getId();
    }

    public void setOrderId(String paymentId, String orderId) {
        paymentRepository.updateOrderId(paymentId, orderId);
    }


}
