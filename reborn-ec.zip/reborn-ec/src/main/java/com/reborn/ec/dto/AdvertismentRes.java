package com.reborn.ec.dto;


import lombok.Data;

@Data
public class AdvertismentRes {
    String advertismentID;
    String title;
    String subtitle;
    String content;
    String coverImg;
}
