package com.reborn.ec.constant;

import java.util.HashMap;
import java.util.Map;

public enum OrderStatus {
    // CREATED("created", (byte) 0),
    // PAID("paid", (byte) 1),
    // DELIVERED("delivered", (byte) 2),
    // CANCELLED("cancelled", (byte) 3), //applied
    // CONFIRMED("confirmed", (byte) 4), //
    // APPLYCANCEL("applycancel", (byte) 5), //authorized
    // REJECTCANCEL("rejectcancel", (byte) 6), //rejected
    // DUMMY("DUMMY", (byte) 999999);

	//支払待ち
    CREATED("created", (byte) 0),
    //現金支払待ち
    CASH("cash", (byte) 1),
    //支払完了
    PAID("paid", (byte) 2),
    //オーダー確認
    CONFIRMED("confirmed", (byte) 3),
    //配達中
    DELIVERING("delivering", (byte) 4),
    //配達完了
    DELIVERED("delivered", (byte) 5),
    //返品リクエスト
    PENDINGRETURN("pendingreturn", (byte) 6),
    //返品承認
    AUTORIZERETURN("authorizereturn", (byte) 7),
    //返品却下
    CLOSERETURN("closereturn", (byte) 8),
    //返金待ち
    PENDINGREFUND("pendingrefund", (byte) 9),
    //返金完了
    COMPLETEREFUND("completerefund", (byte) 10),
    //注文キャンセル
    CANCELLED("cancelled", (byte) 11),

    DUMMY("DUMMY", (byte) 63);

    private final String status;
    private final byte b;

    OrderStatus(String status, byte b) {
        this.status = status;
        this.b = b;
    }

    public static Map<Integer, String> getAllStatus() {
        Map<Integer, String> map = new HashMap<>();
        for (OrderStatus status : OrderStatus.values()) {
            map.put((int) status.b, status.status);
        }
        return map;
    }

    public byte getByteValue() {
        return b;
    }
    public int getIntValue(){
        return Byte.toUnsignedInt(b);
    }
}
