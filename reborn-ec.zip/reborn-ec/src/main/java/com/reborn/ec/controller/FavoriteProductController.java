package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.FavoriteProductInfo;
import com.reborn.ec.dto.FavoriteProductReq;
import com.reborn.ec.model.FavoriteProduct;
import com.reborn.ec.service.FavoriteProductService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@RolesAllowed({"ROLE_CUSTOMER"})
public class FavoriteProductController {

    private final FavoriteProductService FavoriteProductService;
    
    @Autowired
    public FavoriteProductController(FavoriteProductService FavoriteProductService) {
        this.FavoriteProductService = FavoriteProductService;
    }

    @GetMapping("/favorite/list")
    public BaseResponse<List<FavoriteProductInfo>> listFavoriteProduct(@RequestHeader HttpHeaders header) {
        return FavoriteProductService.listFavoriteProduct(header);
    }

    @PostMapping("/favorite/product")
    public BaseResponse<FavoriteProduct> FavoriteProduct(@RequestHeader HttpHeaders header,@RequestBody FavoriteProductReq product) {
        return FavoriteProductService.FavoriteProduct(header,product);
    }
}
