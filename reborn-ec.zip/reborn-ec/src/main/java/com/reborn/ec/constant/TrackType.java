package com.reborn.ec.constant;

import java.util.HashMap;
import java.util.Map;

public enum TrackType {
    WEEK("WEEK",  0),
    MONTH("MONTH" ,1),
    YEAR("YEAR" ,2);


    private final String comment;
    private final Integer intValue;

    TrackType(String comment, Integer intValue) {
        this.comment = comment;
        this.intValue = intValue;
    }

    public static Map<Integer, String> getAllStatus() {
        Map<Integer, String> map = new HashMap<>();
        for (TrackType trackType : TrackType.values()) {
            map.put((int) trackType.intValue, trackType.comment);
        }
        return map;

    }

    public String getComment() {
        return comment;
    }
    public Integer getIntValue() {
        return intValue;
    }
}

