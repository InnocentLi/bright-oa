package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.CustomerReturnReq;
import com.reborn.ec.dto.OrderInfo;
import com.reborn.ec.dto.OrderView;
import com.reborn.ec.model.Order;
import com.reborn.ec.service.OrderService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@RolesAllowed({"ROLE_CUSTOMER"})
public class CustomerOrderController {
    private final OrderService orderService;

    @Autowired
    public CustomerOrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * 创建订单
     * @param header
     * @param orderInfo
     * @return 订单信息
     */
    @PostMapping("/order/create")
//    @RolesAllowed("ROLE_CUSTOMER")
    public BaseResponse<OrderView> createOrder(@RequestHeader HttpHeaders header, @RequestBody OrderInfo orderInfo) {
        return orderService.createOrder(header, orderInfo);
    }

    /**
     * 查看当前用户所有订单
     * @param header
     * @return 订单信息
     */
    @GetMapping("/order/list")
    public BaseResponse<List<OrderView>> getOrderList(@RequestHeader HttpHeaders header) {
        return orderService.getOrderList(header);
    }

    /**
     * 查询订单详情
     * @param header
     * @param orderId
     * @return 订单信息
     */
    @GetMapping("/order/{orderId}")
    public BaseResponse<OrderView> getOrder(@RequestHeader HttpHeaders header, @PathVariable String orderId) {
        return orderService.getOrderDetails(header, orderId);
    }

    @PostMapping("/order/customer/return")
    public BaseResponse<Order> applyReturnOrder(@RequestHeader HttpHeaders header, @RequestBody CustomerReturnReq returnReq) {
        return orderService.applyReturnOrder(header, returnReq);
    }

    @GetMapping("/order/list/return")
    public BaseResponse<List<OrderView>> getReturnList(@RequestHeader HttpHeaders header) {
        return orderService.getReturnList(header);
    }
}
