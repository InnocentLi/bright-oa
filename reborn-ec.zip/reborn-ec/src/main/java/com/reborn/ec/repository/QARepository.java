package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.QA;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface QARepository extends JpaRepository<QA, String> {

    @Query(value="SELECT q from QA q where q.id = :id and q.deleteFlag = 0")
    Optional<QA> findById(String id);

    @Query("SELECT q FROM QA q WHERE q.deleteFlag = 0")
    List<QA> findAll();

    @Modifying
    @Query(value="UPDATE QA SET deleteFlag = 1 WHERE id = :id")
    void deleteQA(@Param("id") String id);
}
//@Query(value="UPDATE qa SET deleteFlag = 1 WHERE id = :id", nativeQuery = true)