package com.reborn.ec.dto;

import lombok.Data;

import java.sql.Timestamp;
import java.util.List;

import com.reborn.ec.model.Shop;

@Data
public class ShopView {
    private String shopId;
    private String name;
    private String description;
    private String addressId;
    private String phone;
    private String ownerId;
    private String companyId;
    private String bannerImage;
    private Timestamp createdAt;
    private Timestamp updatedAt;


    public ShopView(Shop shop) {
        this.shopId = shop.getId();
        this.name = shop.getName();
        this.description = shop.getDescription();
        this.addressId = shop.getAddressId();
        this.phone = shop.getPhone();
        this.ownerId = shop.getUserId();
        this.companyId = shop.getCompanyId();
        this.bannerImage = shop.getBannerImage();
        this.createdAt = shop.getCreatedAt();
        this.updatedAt = shop.getUpdatedAt();
    }

    public static List<ShopView> convert(List<Shop> shopList) {
        List<ShopView> shopViewList = new java.util.ArrayList<>();
        for (Shop shop : shopList) {
            shopViewList.add(new ShopView(shop));
        }
        return shopViewList;
    }
}
