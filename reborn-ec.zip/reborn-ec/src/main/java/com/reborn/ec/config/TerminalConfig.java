package com.reborn.ec.config;

import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
@Data
@Component
@Configuration
@ConfigurationProperties(prefix = "terminalandrole")
public class TerminalConfig {
    
// //     CustomerApp :
// //     - CUSTOMER
//     private List<String> customerApp;
// //   ShopWeb:
// //     - SHOP
// //     - ADMIN
// private List<String> shopWeb;
// //   CustomerWeb:
// //     - CUSTOMER
// private List<String> customerWeb;
    private final Logger logger = LogManager.getLogger(TerminalConfig.class);

    private HashMap<String ,List<String>> acceptRoleMap;
    public List<String>getRoles(String terminalType){
        List<String> ret = null;
        logger.info("terminalType ++++"+ terminalType);
        if(this.acceptRoleMap.get(terminalType) != null){
            ret = acceptRoleMap.get(terminalType);
        }
        // logger.info(" getRoles ret ++++"+ ret.toString());
        return ret;
    }
}
