package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.FavoriteProduct;

import java.util.List;
import java.util.Optional;

@Repository
public interface FavoriteProductRepository extends JpaRepository<FavoriteProduct, String> {

    @Query("SELECT f FROM FavoriteProduct f WHERE f.userId = :userId AND f.deleteFlag = 0")
    List<FavoriteProduct> findByUserId(@Param("userId") String userId);

    @Query("SELECT f FROM FavoriteProduct f WHERE f.userId = :userId AND f.productId = :productId AND f.deleteFlag = 0" )
    Optional<FavoriteProduct> findByUserIdAndProductId(@Param("userId") String userId, @Param("productId") String productId);
}