package com.reborn.ec.service;

import org.springframework.stereotype.Service;

@Service
public class ShipService {

    public String getAShipPhone() {
        // TODO
        return "123456789";
    }
}
