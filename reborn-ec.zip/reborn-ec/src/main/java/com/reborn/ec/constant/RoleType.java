package com.reborn.ec.constant;

import java.util.List;

public enum RoleType {
    CUSTOMER,
    ADMIN,
    SHOPOWNER;

    public static List<String> getAllRoleIds() {
        return List.of(CUSTOMER.name(), ADMIN.name(), SHOPOWNER.name());
    }

    public String getRoleId() {
        return name();
    }

}
