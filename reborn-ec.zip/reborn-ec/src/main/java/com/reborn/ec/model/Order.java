package com.reborn.ec.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@DynamicUpdate(true)
@Table(name = "orders", schema = "rebornecdb")
public class Order {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator="system-uuid")
    @GenericGenerator(name="system-uuid", strategy = "uuid")
    private String id;
    @Basic
    @Column(name = "user_id")
    private String userId;
    @Basic
    @Column(name = "total_price")
    private int totalPrice;
    // delete_flag: 0: not delete, 1: delete
    @Column(name = "delete_flag", columnDefinition = "TINYINT(1) NOT NULL DEFAULT 0")
    private byte deleteFlag;
    @Basic
    @Column(name = "created_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @CreationTimestamp
    private Timestamp createdAt;
    @Basic
    @Column(name = "updated_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    @UpdateTimestamp
    private Timestamp updatedAt;
    @Basic
    @Column(name = "payment_id")
    private String paymentId;
    @Basic
    @Column(name = "address_id")
    private String addressId;
    @Basic
    @Column(name = "shop_id")
    private String shopId;
    @Basic
    @Column(name = "ship_phone")
    private String shipPhone;
    @Basic
    @Column(name = "status_code")
    private byte statusCode;
    @Basic
    @Column(name = "shop_comment")
    private String shopComment;

    @Transient
    private String statusDesString;

    @Transient
    private boolean canReturn = false;

    @Basic
    @Column(name = "delivery_time")
    private String deliveryTime;

    @Basic
    @Column(name = "return_reason")
    private String returnReason;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Order order = (Order) o;
        return id != null && Objects.equals(id, order.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }


}
