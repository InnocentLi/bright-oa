package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.reborn.ec.model.Order;

import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, String> {

    @Query("SELECT o FROM Order o WHERE o.id = ?1 AND o.deleteFlag = 0")
    Optional<Order> findById(String orderId);

    @Query("select o.addressId from Order o where o.id = ?1 and o.deleteFlag = 0")
    String findAddressIdById(String orderId);

    @Query("SELECT o.paymentId FROM Order o WHERE o.id = ?1 AND o.deleteFlag = 0")
    String findPaymentIdById(String orderId);

    @Query("SELECT o FROM Order o WHERE o.userId = ?1 AND o.deleteFlag = 0 ORDER BY o.createdAt DESC")
    List<Order> findByUserId(String myId);

    @Query("SELECT o FROM Order o WHERE o.userId = ?1 AND o.deleteFlag = 0 AND o.statusCode BETWEEN 4 AND 8 ORDER BY o.createdAt DESC")
    List<Order> findReturnOrderByUserId(String myId);

    @Query("SELECT o FROM Order o WHERE o.shopId = :shopId AND o.deleteFlag = 0 AND o.statusCode BETWEEN 4 AND 8 ORDER BY o.createdAt DESC")
    List<Order> findReturnOrderByShopId(@Param("shopId") String shopId);

    @Query("SELECT o FROM Order o WHERE o.shopId = :shopId AND o.deleteFlag = 0 ORDER BY o.createdAt DESC")
    List<Order> findOrderListByShopId(@Param("shopId") String shopId);
}