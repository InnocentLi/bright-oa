package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.reborn.ec.model.Shop;

import java.util.List;
import java.util.Optional;

public interface ShopRepository extends JpaRepository<Shop, String> {

    @Query("select s from Shop s where s.userId = ?1 and s.deleteFlag = 0")
    Optional<Shop> findByUserId(String userId);

    @Query("select s from Shop s where s.id = ?1 and s.deleteFlag = 0")
    Optional<Shop> findById(String id);

    @Query("select s from Shop s where s.deleteFlag = 0")
    List<Shop> findAll();

    @Query("SELECT s.userId FROM Shop s WHERE s.deleteFlag = 0")
    List<String> findAllUserIds();

    @Modifying(clearAutomatically = true)
    @Query("update Shop s set s.deleteFlag = 1 where s.id = ?1 and s.deleteFlag = 0")
    void deleteById(String id);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE Shop s SET s.bannerImage = ?2 WHERE s.id = ?1")
    void updateImage(String id, String bannerImage);

}