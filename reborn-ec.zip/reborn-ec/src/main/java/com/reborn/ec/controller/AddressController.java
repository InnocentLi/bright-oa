package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.model.Address;
import com.reborn.ec.service.AddressService;

import java.util.List;

@RestController
public class AddressController {
    private final AddressService service;

    @Autowired
    public AddressController(AddressService service) {
        this.service = service;
    }

    // 创建住所
    @PostMapping("/address/create")
    public BaseResponse<Address> createAddress(@RequestHeader HttpHeaders header, @RequestBody Address address) {
        return service.createAddress(header, address);
    }

    // 更改住所
    @PostMapping("/address/update")
    public BaseResponse<Address> updateAddress(@RequestHeader HttpHeaders header, @RequestBody Address address) {
        return service.updateAddress(header, address);
    }

    // 获取住所列表信息
    @GetMapping("/address/list")
    public BaseResponse<List<Address>> getAllAddress(@RequestHeader HttpHeaders header) {
        return service.getMyAddressList(header);
    }

    // 获取单个住所信息
    @GetMapping("/address/detail")
    public BaseResponse<Address> getAddress(@RequestHeader HttpHeaders header, @RequestParam String id) {
        return service.getAddress(header, id);
    }

    // 删除住所
    @PostMapping("/address/delete")
    public BaseResponse<Address> deleteAddress(@RequestHeader HttpHeaders header, @RequestBody Address address) {
        return service.deleteAddress(header, address);
    }

}
