package com.reborn.ec.dto;

import lombok.Data;

@Data
public class ShopReturnReq {
    private String orderId;
}
