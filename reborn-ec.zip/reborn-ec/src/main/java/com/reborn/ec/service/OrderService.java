package com.reborn.ec.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.constant.OrderStatus;
import com.reborn.ec.dto.ChangeOrderStatusReq;
import com.reborn.ec.dto.CustomerReturnReq;
import com.reborn.ec.dto.OrderInfo;
import com.reborn.ec.dto.OrderItem;
import com.reborn.ec.dto.OrderView;
import com.reborn.ec.dto.ShopReturnReq;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.Address;
import com.reborn.ec.model.Order;
import com.reborn.ec.model.OrderDetail;
import com.reborn.ec.model.User;
import com.reborn.ec.repository.AddressRepository;
import com.reborn.ec.repository.OrderDetailRepository;
import com.reborn.ec.repository.OrderRepository;
import com.reborn.ec.repository.PaymentRepository;
import com.reborn.ec.repository.ProductRepository;
import com.reborn.ec.repository.ShopRepository;
import com.reborn.ec.repository.UserRepository;

import jakarta.ws.rs.core.Response;

@Service
public class OrderService {
	private final OrderRepository orderRepository;
	private final UserService userService;
	private final OrderDetailRepository orderDetailRepository;
	private final ProductRepository productRepository;
	private final AddressRepository addressRepository;
	private final PaymentRepository paymentRepository;
	private final UserRepository userRepository;
	private final ShopRepository shopRepository;
	private final ShipService shipService;
	private final PaymentService paymentService;
	private final LocalLanguage messageSource;
	private final ShopService shopService;

	private final Logger logger = org.apache.logging.log4j.LogManager.getLogger(OrderService.class);

	@Autowired
	public OrderService(OrderRepository orderRepository, UserService userService, OrderDetailRepository orderDetailRepository, ProductRepository productRepository, AddressRepository addressRepository, PaymentRepository paymentRepository, UserRepository userRepository, ShopRepository shopRepository, ShipService shipService, PaymentService paymentService, ShopService shopService, LocalLanguage messageSource) {
		this.orderRepository = orderRepository;
		this.userService = userService;
		this.orderDetailRepository = orderDetailRepository;
		this.productRepository = productRepository;
		this.addressRepository = addressRepository;
		this.paymentRepository = paymentRepository;
		this.userRepository = userRepository;
		this.shopRepository = shopRepository;
		this.shipService = shipService;
		this.paymentService = paymentService;
		this.messageSource = messageSource;
		this.shopService = shopService;
	}

	private Order createOrder(OrderInfo orderInfo) {
		Order order = new Order();
		order.setUserId(userService.getMyId());
		order.setAddressId(orderInfo.getAddressId());
		order.setShipPhone(shipService.getAShipPhone());
		order.setShopId(orderInfo.getShopId());
		order.setDeliveryTime(orderInfo.getDeliveryTime());
		String paymentId = paymentService.createPayment();
		order.setPaymentId(paymentId);

		if ("cash".equals(orderInfo.getPayMethod())) {
			order.setStatusCode(OrderStatus.CASH.getByteValue());
		} else {
			setStatusCode(order);
		}

		try {
			int price = 0;
			for (OrderItem orderItem : orderInfo.getOrderItems()) {
				price += productRepository.findById(orderItem.getProductId()).get().getPrice() * orderItem.getQuantity();
			}
			order.setTotalPrice(price);
			String orderId = orderRepository.save(order).getId();
			paymentService.setOrderId(paymentId, orderId);
			return order;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Transactional
	public BaseResponse<OrderView> createOrder(HttpHeaders header, OrderInfo orderInfo) {
		BaseResponse<OrderView> res = new BaseResponse<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		OrderView orderView = new OrderView();
		Order order;
		try {
			order = createOrder(orderInfo);
			getStatusDescription(order, lang);
			orderView.setOrder(order);
		} catch (Exception e) {
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			logger.error("create order fail: " + e.getMessage());
			logger.error(e.toString());
			logger.error(e);
			res.setMessage(messageSource.getMessageStr(lang, "order.create.fail"));

			return res;
		}
		try {
			orderView.setOrderDetails(createOrderDetails(orderInfo.getOrderItems(), order));
		} catch (Exception e) {
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			logger.error("create order detail fail: " + e.getMessage());
			res.setMessage(messageSource.getMessageStr(lang, "order.detail.create.fail"));
			return res;
		}
		try {
			orderView.setAddress(addressRepository.findById(order.getAddressId()).get());
		} catch (Exception e) {
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			logger.error("address fail: " + e.getMessage());
			res.setMessage(messageSource.getMessageStr(lang, "wrong address"));
			return res;
		}
		try {
			orderView.setPayment(paymentRepository.findById(order.getPaymentId()).get());
		} catch (Exception e) {
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			logger.error("address fail: " + e.getMessage());
			res.setMessage(messageSource.getMessageStr(lang, "payment wrong"));
			return res;
		}
		setOrderCanReturn(orderView);
		res.setData(orderView);
		res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
		res.setMessage(messageSource.getMessageStr(lang, "order.create.success"));
		return res;
	}

	private void setStatusCode(Order order) {
		// TODO
		order.setStatusCode(OrderStatus.CREATED.getByteValue());
	}

	private void getStatusDescription(Order order, String lang) {
		// TODO
		order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.null"));
		if (order.getStatusCode() == OrderStatus.CREATED.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.created"));
		}
		if (order.getStatusCode() == OrderStatus.PAID.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.paid"));
		}
		if (order.getStatusCode() == OrderStatus.CONFIRMED.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.confirmed"));
		}
		if (order.getStatusCode() == OrderStatus.DELIVERED.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.delivered"));
		}
		if (order.getStatusCode() == OrderStatus.PENDINGRETURN.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.pendingreturn"));
		}
		if (order.getStatusCode() == OrderStatus.AUTORIZERETURN.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.authorizereturn"));
		}
		if (order.getStatusCode() == OrderStatus.CLOSERETURN.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.closereturn"));
		}
		if (order.getStatusCode() == OrderStatus.PENDINGREFUND.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.pendingrefund"));
		}
		if (order.getStatusCode() == OrderStatus.COMPLETEREFUND.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.completerefund"));
		}
		if (order.getStatusCode() == OrderStatus.CANCELLED.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.cancelled"));
		}
		// 現金支払待ち追加
		if (order.getStatusCode() == OrderStatus.CASH.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.cash"));
		}
		// 配達中追加
		if (order.getStatusCode() == OrderStatus.DELIVERING.getByteValue()) {
			order.setStatusDesString(messageSource.getMessageStr(lang, "order.status.delivering"));
		}

	}

	private List<OrderDetail> createOrderDetails(List<OrderItem> orderItems, Order order) {
		List<OrderDetail> orderDetails = new ArrayList<>();
		try {
			for (OrderItem orderItem : orderItems) {
				OrderDetail orderDetail = new OrderDetail();
				orderDetail.setOrderId(order.getId());
				orderDetail.setProductId(orderItem.getProductId());
				orderDetail.setQuantity(orderItem.getQuantity());
				orderDetail.setPrice(productRepository.findById(orderItem.getProductId()).get().getPrice());
				orderDetail.setProductDesc(productRepository.findById(orderItem.getProductId()).get().getDescription());
				orderDetail.setProductImg(productRepository.findById(orderItem.getProductId()).get().getImage());
				orderDetail.setProductName(productRepository.findById(orderItem.getProductId()).get().getName());
				orderDetails.add(orderDetailRepository.save(orderDetail));
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return orderDetails;
	}

	@Transactional
	public BaseResponse<OrderView> getOrderDetails(HttpHeaders header, String orderId) {
		BaseResponse<OrderView> res = new BaseResponse<>();
		OrderView orderView = new OrderView();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		try {
			Address address = addressRepository.findById(orderRepository.findAddressIdById(orderId)).get();
			orderView.setAddress(address);
		} catch (Exception e) {
			res.setCode(String.valueOf(Response.Status.UNAUTHORIZED.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
			return res;
		}
		orderView.setPayment(paymentRepository.findById(orderRepository.findPaymentIdById(orderId)).get());
		orderView.setOrderDetails(orderDetailRepository.findByOrderId(orderId));
		orderView.setOrder(orderRepository.findById(orderId).get());
		orderView.setShopName(shopRepository.findById(orderRepository.findById(orderId).get().getShopId()).get().getName());
		orderView.setShopBannerImage(shopRepository.findById(orderRepository.findById(orderId).get().getShopId()).get().getBannerImage());
		getStatusDescription(orderView.getOrder(), lang);
		this.setOrderCanReturn(orderView);
		res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));

		res.setMessage(messageSource.getMessageStr(lang, "order.get.success"));
		res.setData(orderView);
		return res;

	}

	private final int canReturnMinutes = 15;

	private void setOrderCanReturn(OrderView orderView) {
		OrderView retOrderView = orderView;
		if (retOrderView != null && retOrderView.getOrder() != null) {
			if (retOrderView.getOrder().getStatusCode() == OrderStatus.PAID.getByteValue() || retOrderView.getOrder().getStatusCode() == OrderStatus.CREATED.getByteValue()) {
				Timestamp createAt = retOrderView.getOrder().getCreatedAt();
				DateTime createdDate = new DateTime(createAt.getTime());
				createdDate = createdDate.plusMinutes(canReturnMinutes);
				if (createdDate.isAfterNow()) {
					orderView.getOrder().setCanReturn(true);
				}
			}
		}
	}

	public BaseResponse<List<OrderView>> getOrderList(HttpHeaders header) {
		BaseResponse<List<OrderView>> res = new BaseResponse<>();
		List<OrderView> orderViews = new ArrayList<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		try {
			List<Order> orders = orderRepository.findByUserId(userService.getMyId());
			setOrderView(orderViews, lang, orders);
		} catch (Exception e) {
			res.setCode(String.valueOf(Response.Status.UNAUTHORIZED.getStatusCode()));

			res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
			return res;
		}
		res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
		res.setMessage(messageSource.getMessageStr(lang, "order.get.success"));
		res.setData(orderViews);
		return res;
	}

	private void setOrderView(List<OrderView> orderViews, String lang, List<Order> orders) {
		for (Order order : orders) {
			OrderView orderView = new OrderView();
			orderView.setOrder(order);
			getStatusDescription(orderView.getOrder(), lang);
			this.setOrderCanReturn(orderView);
			orderView.setOrderDetails(orderDetailRepository.findByOrderId(order.getId()));
			orderView.setAddress(addressRepository.findById(order.getAddressId()).get());
			orderView.setPayment(paymentRepository.findById(order.getPaymentId()).get());
			orderView.setShopName(shopRepository.findById(order.getShopId()).get().getName());
			orderView.setShopBannerImage(shopRepository.findById(order.getShopId()).get().getBannerImage());
			orderViews.add(orderView);
		}
	}

	public BaseResponse<List<OrderView>> getReturnList(HttpHeaders header) {
		BaseResponse<List<OrderView>> res = new BaseResponse<>();
		List<OrderView> orderViews = new ArrayList<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		try {
			List<Order> orders = orderRepository.findReturnOrderByUserId(userService.getMyId());
			setOrderView(orderViews, lang, orders);
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
			return res;
		}
		res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
		res.setMessage(messageSource.getMessageStr(lang, "order.get.success"));
		res.setData(orderViews);
		return res;
	}

	public BaseResponse<Order> applyReturnOrder(HttpHeaders header, CustomerReturnReq returnReq) {
		BaseResponse<Order> res = new BaseResponse<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		Optional<Order> orderOpt = orderRepository.findById(returnReq.getOrderId());
		if (orderOpt.isPresent()) {
			Order order = orderOpt.get();
			if (order != null && order.getStatusCode() == OrderStatus.PAID.getByteValue()) {
				order.setStatusCode(OrderStatus.PENDINGRETURN.getByteValue());
				order.setReturnReason(returnReq.getReturnReason());
				orderRepository.save(order);
				res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
				res.setMessage(messageSource.getMessageStr(lang, "success"));
			} else if (order != null && order.getStatusCode() == OrderStatus.CREATED.getByteValue()) {
				order.setStatusCode(OrderStatus.CANCELLED.getByteValue());
				orderRepository.save(order);
				res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
				res.setMessage(messageSource.getMessageStr(lang, "success"));
			} else {
				res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
				res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
			}
			res.setData(order);
		} else {
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
		}

		return res;
	}

	public BaseResponse<Order> confirmReturnOrder(HttpHeaders header, ShopReturnReq returnReq) {
		BaseResponse<Order> res = new BaseResponse<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		Optional<Order> orderOpt = orderRepository.findById(returnReq.getOrderId());
		if (orderOpt.isPresent()) {
			Order order = orderOpt.get();
			if (order != null && order.getStatusCode() == OrderStatus.PENDINGRETURN.getByteValue()) {
				order.setStatusCode(OrderStatus.AUTORIZERETURN.getByteValue());
				orderRepository.save(order);
				res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
				res.setMessage(messageSource.getMessageStr(lang, "order.status.authorizereturn"));
			} else {
				res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
				res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
			}
			res.setData(order);
		} else {
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
		}

		return res;
	}

	public BaseResponse<List<OrderView>> getShopReturnList(HttpHeaders header) {
		BaseResponse<List<OrderView>> res = new BaseResponse<>();
		List<OrderView> orderViews = new ArrayList<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		// ------------------------previous version------------------------
		// try{
		// String shopId = shopService.getShopId();
		// List<Order> orders = orderRepository.findReturnOrderByShopId(shopId);
		// setOrderView(orderViews, lang, orders);
		// } catch (Exception e) {
		// logger.error(e);
		// e.printStackTrace();
		// res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
		// res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
		// return res;
		// }
		try {
			String shopId = shopService.getShopId();
			List<Order> orders = orderRepository.findReturnOrderByShopId(shopId);
			for (Order order : orders) {
				OrderView orderView = new OrderView();
				orderView.setOrder(order);
				getStatusDescription(orderView.getOrder(), lang);
				this.setOrderCanReturn(orderView);
				orderView.setOrderDetails(orderDetailRepository.findByOrderId(order.getId()));
				Optional<Address> optAddress = addressRepository.findById(order.getAddressId());
				if (optAddress.isPresent()) {
					orderView.setAddress(optAddress.get());
				} else {
					logger.error("address not found");
				}
				Optional<User> optUser = userRepository.findById(order.getUserId());
				if (optUser.isPresent()) {
					orderView.setUsername(optUser.get().getUsername());
				} else {
					logger.error("payment not found");
				}
				orderViews.add(orderView);
			}
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
			return res;
		}
		res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
		res.setMessage(messageSource.getMessageStr(lang, "order.get.success"));
		res.setData(orderViews);
		return res;
	}

	// get the order list of the shop
	public BaseResponse<List<OrderView>> getShopOrderList(HttpHeaders header) {
		BaseResponse<List<OrderView>> res = new BaseResponse<>();
		List<OrderView> orderViews = new ArrayList<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		try {
			String shopId = shopService.getShopId();
			List<Order> orders = orderRepository.findOrderListByShopId(shopId);
			for (Order order : orders) {
				OrderView orderView = new OrderView();
				orderView.setOrder(order);
				getStatusDescription(orderView.getOrder(), lang);
				this.setOrderCanReturn(orderView);
				orderView.setOrderDetails(orderDetailRepository.findByOrderId(order.getId()));
				Optional<Address> optAddress = addressRepository.findById(order.getAddressId());
				if (optAddress.isPresent()) {
					orderView.setAddress(optAddress.get());
				} else {
					logger.error("address not found");
				}
				// Optional<Payment> optPayment =
				// paymentRepository.findById(order.getPaymentId());
				// if (optPayment.isPresent()) {
				// orderView.setPayment(optPayment.get());
				// } else {
				// logger.error("payment not found");
				// }
				Optional<User> optUser = userRepository.findById(order.getUserId());
				if (optUser.isPresent()) {
					orderView.setUsername(optUser.get().getUsername());
				} else {
					logger.error("payment not found");
				}
				orderViews.add(orderView);
			}
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "order.get.fail"));
			return res;
		}
		res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
		res.setMessage(messageSource.getMessageStr(lang, "order.get.success"));
		res.setData(orderViews);
		return res;
	}

	public BaseResponse<Order> changeOrderStatus(HttpHeaders header, ChangeOrderStatusReq changeOrderStatusReq, String orderId) {
		BaseResponse<Order> res = new BaseResponse<>();
		String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
		Optional<Order> orderOpt = orderRepository.findById(orderId);
		if (orderOpt.isPresent()) {
			Order order = orderOpt.get();
			order.setStatusCode(changeOrderStatusReq.getStatusCode());
			order.setShopComment(changeOrderStatusReq.getShopComment());
			orderRepository.save(order);
			res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "success"));
			res.setData(order);
		} else {
			res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			res.setMessage(messageSource.getMessageStr(lang, "order.not.found"));
		}

		return res;
	}

	// 領収書HTML印刷(Invoice)
}
