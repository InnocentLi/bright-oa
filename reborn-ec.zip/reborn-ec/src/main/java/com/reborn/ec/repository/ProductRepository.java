package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.Product;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, String> {

    @Query("SELECT p FROM Product p WHERE p.id = ?1 AND p.deleteFlag = 0")
    Optional<Product> findById(String id);

    @Query("SELECT p FROM Product p WHERE p.deleteFlag = 0")
    List<Product> findAll();

    @Query("SELECT p FROM Product p WHERE p.shopId = ?1 AND p.deleteFlag = 0")
    List<Product> findByShopIdByShopOwner(String shopId);

    @Query("SELECT p FROM Product p WHERE p.shopId = ?1 AND p.deleteFlag = 0 AND p.status = 1")
    List<Product> findByShopIdByCustomer(String shopId);

    List<Product> findByShopIdAndStatus(String shopId, int status);

    @Query(value="SELECT p FROM Product p WHERE p.name like %:name% AND p.deleteFlag = 0 AND p.status = 1")
    List<Product> findAllByNameLike(String name);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE Product p SET p.deleteFlag = 1 WHERE p.id = ?1")
    void deleteById(String id);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE Product p SET p.image = ?2 WHERE p.id = ?1")
    void updateImage(String id, String image);

    @Query("SELECT p FROM Product p WHERE p.shopId = ?2 AND p.deleteFlag = 0 AND p.id = ?1")
    Optional<Product> findByIdAndShopId(String productId, String shopId);
}