package com.reborn.ec.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.OrderStatus;
import com.reborn.ec.constant.RoleType;
import com.reborn.ec.constant.UserStatus;

import javax.annotation.security.RolesAllowed;
import java.util.List;
import java.util.Map;

@RestController
public class ConstantController {

    /**
     * 获取所有角色
     * @return roles
     */
    @GetMapping("/admin/constants/role-ids")
    @RolesAllowed("ROLE_ADMIN")
    public BaseResponse<List<String>> roleids() {
        BaseResponse<List<String>> response = new BaseResponse<>();
        response.setData(RoleType.getAllRoleIds());
        response.setCode("200");
        response.setMessage("success");
        return response;
    }

    /**
     * 获取所有用户状态
     * return a map like {0: "active", 1: "blocked"}
     * @return status
     */
    @GetMapping("/admin/constants/user-status")
    @RolesAllowed("ROLE_ADMIN")
    public BaseResponse<Map<Integer, String>> userStatus() {
        BaseResponse<Map<Integer, String>> response = new BaseResponse<>();
        response.setData(UserStatus.getAllStatus());
        response.setCode("200");
        response.setMessage("success");
        return response;
    }

    /**
     * 获取所有订单状态
     * return a map like {0: "active", 1: "blocked"}
     * @return status
     */
    @GetMapping("/shop/constants/order-status")
    @RolesAllowed("ROLE_SHOPOWNER")
    public BaseResponse<Map<Integer, String>> orderStatus() {
        BaseResponse<Map<Integer, String>> response = new BaseResponse<>();
        response.setData(OrderStatus.getAllStatus());
        response.setCode("200");
        response.setMessage("success");
        return response;
    }


}
