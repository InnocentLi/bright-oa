package com.reborn.ec.service;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.ProductInfo;
import com.reborn.ec.model.Product;
import com.reborn.ec.repository.FavoriteProductRepository;
import com.reborn.ec.repository.ProductRepository;
import com.reborn.ec.repository.ShopRepository;
import com.reborn.ec.repository.UserRepository;
import com.reborn.ec.util.Common;

import java.util.List;
import java.util.Optional;


@Service
@Slf4j
public class ProductService {

    private ProductRepository productRepository;
    private FavoriteProductRepository favoriteProductRepository;
    // private UserRepository userRepository;

    // private ShopRepository shopRepository;

    private final ShopService shopService;
    private final UserService userService;

    private AWSService awsService;

    private final Logger logger = org.apache.logging.log4j.LogManager.getLogger(ProductService.class);

    @Autowired
    public ProductService(  ProductRepository productRepository, 
                            UserRepository userRepository, 
                            ShopRepository shopRepository, 
                            FavoriteProductRepository favoriteProductRepository,
                            ShopService shopService, 
                            AWSService awsService, 
                            UserService userService) {
        this.productRepository = productRepository;
        this.favoriteProductRepository = favoriteProductRepository;
        //this.userRepository = userRepository;
        // this.shopRepository = shopRepository;
        this.shopService = shopService;
        this.awsService = awsService;
        this.userService = userService;

        // this.shopId = shopService.getShopId();
        // this.userService = userService;
    }


    public BaseResponse<List<Product>> getProducts(HttpHeaders header, String shopId) {
        BaseResponse<List<Product>> ret = new BaseResponse<List<Product>>();

        // get principal's role
        String role = SecurityContextHolder.getContext().getAuthentication().getAuthorities().toArray()[0].toString();

        try{
            // if (role.equals("ADMIN")) { // role is ADMIN, return all products
            //     ret.setData(productRepository.findByShopId(shopId));
            // } else { // role is USER, get only selling or sold out products
            //     List<Product> products = productRepository.findByShopIdAndStatus(shopId, 1);
            //     products.addAll(productRepository.findByShopIdAndStatus(shopId, 2));
            //     ret.setData(products);
            // }
            ret.setData(productRepository.findByShopIdByCustomer(shopId));
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("success");
        } catch (Exception e) {
            logger.error(e.toString());
            logger.error(e);
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("not found");
        }

        return ret;
    }

    public BaseResponse<Product> createProduct(HttpHeaders header, Product productInfo) {
        BaseResponse<Product> ret = new BaseResponse<>();
        try{
            if(productInfo.getShopId() != null && !productInfo.getShopId().equals(shopService.getShopId())) {
                ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
                ret.setMessage("shopId is required or not match");
                return ret;
            }
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("shopId not match");
        }
        try{
            if(productInfo.getShopId()== null || productInfo.getShopId()== ""){
                productInfo.setShopId(shopService.getShopId());
            }
            ret.setData(productRepository.save(productInfo));
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("create success");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to create product");
        }
        return ret;
    }

    public BaseResponse<ProductInfo> getProductDetail(HttpHeaders header, String productId) {
        BaseResponse<ProductInfo> ret = new BaseResponse<>();
        String userId = userService.getMyId();
        ProductInfo productInfo = new ProductInfo();
        try{
            productInfo.setProduct(productRepository.findById(productId).get()); 
            productInfo.setIsFavorited(favoriteProductRepository.findByUserIdAndProductId(userId, productId).isPresent());
            
            ret.setData(productInfo);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("product found");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to get product detail");
        }
        return ret;
    }




    private boolean productBelongsToShop(String  productId) {
        Optional<Product> productOpt = productRepository.findById(productId);
        if(productOpt.isPresent()) {
            Product  product = productOpt.get();
            String shopId = shopService.getShopId();
            return product.getShopId().compareTo(shopId)==0;
        }
        return false;
    }


    @Transactional
    public BaseResponse<Product> updateProduct(HttpHeaders header, Product productInfo) {
        BaseResponse<Product> ret = new BaseResponse<>();

        try {
            if (!productBelongsToShop(productInfo.getId())) {
                ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
                ret.setMessage("product does not belong to this shop or does not exist");
                return ret;
            }
        } catch (RuntimeException e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("product does not belong to this shop or does not exist");
            return ret;
        }

        try{
            Optional<Product> productOpt =productRepository.findById(productInfo.getId());
            Product product = productOpt.get();
            
            BeanUtils.copyProperties(productInfo, product,Common.getNullPropertyNames(productInfo));
            Product productAfter= productRepository.save(product);
            ret.setData(productAfter);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("update success");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to update product");
        }
        return ret;
    }

    @Transactional
    public BaseResponse<Product> updateProductVisibility(HttpHeaders header, String productId) {
        BaseResponse<Product> ret = new BaseResponse<>();
        try {
            if (!productBelongsToShop(productId)) {
                ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
                ret.setMessage("product does not belong to this shop or does not exist");
                return ret;
            }
        } catch (RuntimeException e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("product does not belong to this shop or does not exist");
            return ret;
        }
        try{
            Optional<Product> productOpt =productRepository.findById(productId);
            if (productOpt.isPresent()) {
            Product product = productOpt.get();
            if (product.getStatus() == 0) {
                product.setStatus((byte) 1);
            } else {
                product.setStatus((byte) 0);
            }
            ret.setData(product);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("updated visibility successfully");
            } else {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to update product visibility");
            }
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to update product visibility");
        }
        return ret;
    }

    @Transactional
    public BaseResponse<Product> deleteProduct(HttpHeaders header, String productId) {
        BaseResponse<Product> ret = new BaseResponse<>();

        if (!productBelongsToShop(productId)) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("product does not belong to this shop or does not exist");
            return ret;
        }

        // set product deleteFlag to 1
        try{
            productRepository.deleteById(productId);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("delete success");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to delete product");
        }
        return ret;
    }

    public BaseResponse<List<Product>> getAllProducts(HttpHeaders header) {
        BaseResponse<List<Product>> ret = new BaseResponse<>();
        try{
            List<Product> products = productRepository.findAll();
            ret.setData(products);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("success to get all products");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to get all products");
        }
        return ret;
    }


    public BaseResponse<List<Product>> getSearchedProducts(HttpHeaders header, String productName) {
        BaseResponse<List<Product>> ret = new BaseResponse<>();
        try{
            List<Product> products = productRepository.findAllByNameLike(productName);
            ret.setData(products);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("success to get searched products");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to get searched products");
        }
        return ret;
    }


    @Transactional
    public BaseResponse<String> uploadImage(HttpHeaders header, MultipartFile productImage, String productId) {
        BaseResponse<String> ret = new BaseResponse<>();
        if (!productBelongsToShop(productId)) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("product does not belong to this shop or does not exist");
            return ret;
        }

        String imageS3Url = null;
        String ext = productImage.getOriginalFilename().substring(productImage.getOriginalFilename().lastIndexOf(".")+1);
        String fileName = productId + '.' + ext;

        try{
            imageS3Url = awsService.uploadImage(productImage, "product-images/"+fileName);
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to upload image to cloud");
            return ret;
        }

        try{
            productRepository.updateImage(productId, imageS3Url);
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to upload image to DB");
            return ret;
        }

        ret.setMessage("success to upload image");
        ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
        ret.setData(imageS3Url);
        return ret;
    }

    public BaseResponse<List<Product>> listShopProduct(HttpHeaders header) {
        BaseResponse<List<Product>> ret = new BaseResponse<>();
        try{
            logger.info("shop id: " + shopService.getShopId());
            ret.setData(productRepository.findByShopIdByShopOwner(shopService.getShopId()));
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("success to get products");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to get products");
        }
        return ret;
    }

    public BaseResponse<Product> getShopProductDetail(HttpHeaders header, String productId) {
        BaseResponse<Product> ret = new BaseResponse<>();
        try{
            ret.setData(productRepository.findByIdAndShopId(productId, shopService.getShopId()).get());
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("success to get product detail");
        } catch (Exception e) {
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to get product detail");
        }
        return ret;
    }
}
