package com.reborn.ec.dto;

import lombok.Data;

@Data
public class Account {
    private String username;
    private String password;
    private String email;
    private String phone;
    private String roleId;
    private byte status = -1;
}
