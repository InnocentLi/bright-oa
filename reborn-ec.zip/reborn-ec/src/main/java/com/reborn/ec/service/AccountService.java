package com.reborn.ec.service;

import jakarta.ws.rs.core.Response;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.Account;
import com.reborn.ec.model.User;
import com.reborn.ec.repository.UserRepository;
import com.reborn.ec.util.Common;

import java.util.List;
import java.util.Optional;

@Service
public class AccountService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    private final Logger logger = org.apache.logging.log4j.LogManager.getLogger(AccountService.class);

    @Autowired
    public AccountService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public BaseResponse<List<User>> getAccountList(HttpHeaders header) {
        BaseResponse<List<User>> res = new BaseResponse<>();
        try{
            List<User> users = userRepository.findAll();
            res.setData(users);
            res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            res.setMessage("account.list.success");
        } catch (Exception e) {
            res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
            res.setMessage("account.list.fail");
        }
        return res;
    }

    public BaseResponse<User> createAccount(HttpHeaders header, Account account) {
        BaseResponse<User> res = new BaseResponse<>();
        if(userRepository.existsByUsername(account.getUsername())) {
            res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            res.setMessage("account.create.username.exists");
            return res;
        }
        if(userRepository.existsByEmail(account.getEmail())) {
            res.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            res.setMessage("account.create.email.exists");
            return res;
        }

        try{
            User user = new User();
            user.setUsername(account.getUsername());
            user.setPassword(passwordEncoder.encode(account.getPassword()));
            user.setEmail(account.getEmail());
            user.setPhone(account.getPhone());
            user.setRoleId(account.getRoleId());
            user.setStatus(account.getStatus());
            user.setUserId(account.getUsername());
            res.setData(userRepository.save(user));
            res.setCode(String.valueOf(Response.Status.CREATED.getStatusCode()));
            res.setMessage("account.create.success");
        } catch (Exception e) {
            res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
            res.setMessage("account.create.fail");
        }
        return res;
    }

    public BaseResponse<String> deleteAccount(HttpHeaders header, String userId) {
        BaseResponse<String> res = new BaseResponse<>();
        try{
            userRepository.deleteById(userId);
            res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            res.setData("account.delete.success");
            res.setMessage("account.delete.success");
        } catch (Exception e) {
            res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
            res.setMessage("account.delete.fail");
        }
        return res;
    }


    public BaseResponse<User> updateAccount(HttpHeaders header, Account account, String userId) {
        BaseResponse<User> res = new BaseResponse<>();

        logger.info("updateAccount: " + account.toString());
        Optional<User> user = userRepository.findById(userId);
        if (!user.isPresent()) {
            res.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
            res.setMessage("account.not.found");
            return res;
        }
        User beforeUser = user.get();
        
        // check if user email already exists
        if(account.getEmail() != null && emailExists(account.getEmail(), beforeUser.getEmail())) {
            res.setCode(String.valueOf(Response.Status.CONFLICT.getStatusCode()));
            res.setMessage("account.update.fail.email_exists");
            return res;
        }
        // check if user username already exists
        if(account.getUsername() != null && usernameExists(account.getUsername(), beforeUser.getUsername())) {
            res.setCode(String.valueOf(Response.Status.CONFLICT.getStatusCode()));
            res.setMessage("account.update.fail.username_exists");
            return res;
        }

        if(account.getStatus() == -1){
            account.setStatus(beforeUser.getStatus());
        }

        // encode if password is not null
        if(account.getPassword() != null) {
            account.setPassword(passwordEncoder.encode(account.getPassword()));
        }

        try{
            BeanUtils.copyProperties(account, beforeUser, Common.getNullPropertyNames(account));
            User afterUser = userRepository.save(beforeUser);
            res.setData(afterUser);
            res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            res.setMessage("account.update.success");
            
        } catch (Exception e) {
            res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
            res.setMessage("account.update.fail");
        }
        return res;
    }

    private boolean usernameExists(String afterUsername, String beforeUsername) {
        return !beforeUsername.equals(afterUsername) && userRepository.existsByUsername(afterUsername);
    }

    private boolean emailExists(String afterEmail, String beforeEmail) {
        return !beforeEmail.equals(afterEmail) && userRepository.existsByEmail(afterEmail);
    }

    public BaseResponse<User> queryAccount(HttpHeaders header, String userId) {
        BaseResponse<User> res = new BaseResponse<>();
        try{
            User user = userRepository.findById(userId).get();
            res.setData(user);
            res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            res.setMessage("account.query.success");
        } catch (Exception e) {
            res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
            res.setMessage("account.query.fail");
        }
        return res;
    }
}
