package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.reborn.ec.model.UserToken;

public interface UserTokenRepository extends JpaRepository<UserToken, String> {

    UserToken findByToken(String token);

    @Modifying(clearAutomatically = true)
    @Query(value = "DELETE FROM UserToken WHERE userId = :userId")
    void deleteByUserId(String userId);
}