package com.reborn.ec.dto;

import lombok.Data;

@Data
public class FavoriteProductReq {
    private String name;
    private String productId;
    private String categoryId;
    private String subcategoryId;
    private String shopId;
    private int price;
    private int inventoryQuantity;
    private String image;
    private String description;
}
