package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.model.Product;
import com.reborn.ec.service.ProductService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@RolesAllowed({"ROLE_SHOPOWNER"})
public class ShopProductController {
    private final ProductService productService;

    @Autowired
    public ShopProductController(ProductService productService) {
        this.productService = productService;
    }

    /**
     * 更新商品信息
     * @return 更新后的商品信息
     */
    @PostMapping("shop/product/update/")
    public BaseResponse<Product> updateProduct(@RequestHeader HttpHeaders header, @RequestBody Product productInfo) {
        return productService.updateProduct(header, productInfo);
    }

    /**
     * 设置商品公开与否
     * @return 更新后的商品信息
     */
    @PostMapping("shop/product/update/visibility/{productId}")
    public BaseResponse<Product> updateProductVisibility(@RequestHeader HttpHeaders header, @PathVariable String productId) {
        return productService.updateProductVisibility(header, productId);
    }

    /**
     * 创建商品
     * @param productInfo 商品信息
     * @return 已创建的商品
     */
    @PostMapping("shop/product/create")
    public BaseResponse<Product> createProduct(@RequestHeader HttpHeaders header, @RequestBody Product productInfo) {
        return productService.createProduct(header, productInfo);
    }

    /**
     * 删除商品
     * @param productId 商品 id
     * @return 删除结果
     */
    @PostMapping("shop/product/delete/{productId}")
    public BaseResponse<Product> deleteProduct(@RequestHeader HttpHeaders header, @PathVariable String productId) {
        return productService.deleteProduct(header, productId);
    }


    /**
     * 上传商品图片
     * @param header
     * @param productImage 商品图片信息(productId, image)
     * @return 上传结果
     */
    @PostMapping(path="shop/product/image/upload/{productId}", consumes = "multipart/form-data")
    public BaseResponse<String> uploadImage(@RequestHeader HttpHeaders header, @RequestPart MultipartFile productImage, @PathVariable String productId) {
        return productService.uploadImage(header, productImage, productId);
    }

    /**
     * 店铺商品一览
     * @param header
     * @return 店铺商品
     */
    @GetMapping("shop/product/list")
    public BaseResponse<List<Product>> listProduct(@RequestHeader HttpHeaders header) {
        return productService.listShopProduct(header);
    }

    /**
     * 查看商品详情
     * @param header
     * @param productId 商品 id
     * @return 商品详情
     */
    @GetMapping("shop/product/detail/{productId}")
    public BaseResponse<Product> detailProduct(@RequestHeader HttpHeaders header, @PathVariable String productId) {
        return productService.getShopProductDetail(header, productId);
    }

}
