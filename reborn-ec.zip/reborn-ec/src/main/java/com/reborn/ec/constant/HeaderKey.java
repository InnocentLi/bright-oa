package com.reborn.ec.constant;

public class HeaderKey {

  public static final String localLanguage = "local-language";
  public static final String terminalType = "terminal-type";
}
