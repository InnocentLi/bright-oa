package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.model.FAQ;
import com.reborn.ec.service.FAQService;

import java.util.List;

@RestController
public class FAQController {
    private final FAQService service;

    @Autowired
    public FAQController(FAQService service) {
        this.service = service;
    }

    //获取FAQ列表
    @GetMapping("/faq/list")
    public BaseResponse<List<FAQ>> getAllFAQ(@RequestHeader HttpHeaders header) {
        return service.getAllFAQ(header);
    }

    @GetMapping("/faq/search")
    public BaseResponse<List<FAQ>> getSearchedFAQs(@RequestHeader HttpHeaders header, @RequestParam String question) {
        return service.getSearchedFAQs(header, question);
    }
    
}
