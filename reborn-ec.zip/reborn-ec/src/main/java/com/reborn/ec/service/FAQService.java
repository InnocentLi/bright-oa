package com.reborn.ec.service;

import jakarta.ws.rs.core.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.FAQ;
import com.reborn.ec.repository.FAQRepository;

import java.util.List;


@Service
public class FAQService {
    private final FAQRepository faqRepository;
    private final LocalLanguage messageSource;
    private static final Logger logger = LogManager.getLogger(FAQService.class);
    @Autowired
    public FAQService(FAQRepository faqRepository, LocalLanguage messageSource) {
        this.faqRepository = faqRepository;
        this.messageSource = messageSource;
    }

    //获取FAQ列表
    public BaseResponse<List<FAQ>> getAllFAQ(HttpHeaders header){
        BaseResponse<List<FAQ>> ret = new BaseResponse<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        if(faqRepository.findAll()!=null){
            ret.setCode(String.valueOf(Response.Status.FOUND.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "FAQ.found"));
            ret.setData(faqRepository.findAll());
            return ret;
        }
        ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "FAQ.unfound"));

        return ret;
    }

    public BaseResponse<List<FAQ>> getSearchedFAQs(HttpHeaders header, String question) {
        BaseResponse<List<FAQ>> ret = new BaseResponse<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        try{
            List<FAQ> faqs = faqRepository.findByQuestionLike(question);
            if(faqs.isEmpty()) {
                ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
                ret.setMessage(messageSource.getMessageStr(lang, "FAQ.unfound"));
                return ret;
            }
            ret.setData(faqs);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage("success to get searched faqs");
        } catch (Exception e) {
            logger.error(e.toString());
            logger.error(e);
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage("failed to get searched faqs");
        }
        return ret;
    }
}
