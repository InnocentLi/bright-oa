package com.reborn.ec.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.dto.CommentReq;
import com.reborn.ec.dto.CommentRes;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.Comment;
import com.reborn.ec.repository.CommentRepository;

import jakarta.ws.rs.core.Response;

import java.util.ArrayList;
import java.util.List;

@Service
public class CommentService {
    private final CommentRepository commentRepository;
    private final LocalLanguage messageSource;
    private static final Logger logger = LogManager.getLogger(CommentService.class);

    private final UserService userService;

    @Autowired
    public CommentService(CommentRepository commentRepository, LocalLanguage messageSource, UserService userService) {
        this.commentRepository = commentRepository;
        this.messageSource = messageSource;
        this.userService = userService;
    }

    //商品コメント 追加
    public BaseResponse<CommentRes> createComment(HttpHeaders header, CommentReq comment) {
        BaseResponse<CommentRes> ret = new BaseResponse<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        Comment newComment = new Comment();
        String userID = userService.getMyId();
        String userName = userService.getMyName();
        newComment.setComment(comment.getCommentContent());
        newComment.setProductID(comment.getProductID());
        newComment.setProductName(comment.getProductName());
        newComment.setUserID(userID);
        newComment.setUserName(userName);
        newComment.setDeleteFlag((byte)0);
        Comment insertedComment = new Comment();
        try {
            insertedComment = commentRepository.save(newComment);
        } catch (Exception e) {
            // TODO: handle exception
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "failed"));

            return ret;
        }
        CommentRes retItem = new CommentRes();
        retItem.setCommentContent(insertedComment.getComment());
        retItem.setCommentID(insertedComment.getId());
        retItem.setUserName(insertedComment.getUserName());

        ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "success"));
        ret.setData(retItem);

        return ret;
    }
    //商品コメント リスト
    public BaseResponse<List<CommentRes>> listComment(HttpHeaders header, CommentReq comment) {
        BaseResponse<List<CommentRes>> ret = new BaseResponse<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        List<Comment> comments = commentRepository.findCommentsByProductID(comment.getProductID());
        List<CommentRes> retList = new ArrayList<CommentRes>();
        for (Comment item : comments) {
            CommentRes retItem = new CommentRes();
            retItem.setCommentContent(item.getComment());
            retItem.setCommentID(item.getId());
            retItem.setUserName(item.getUserName());
            retList.add(retItem);
        }
  
        ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "success"));
        ret.setData(retList);
        return ret;
    }
}
