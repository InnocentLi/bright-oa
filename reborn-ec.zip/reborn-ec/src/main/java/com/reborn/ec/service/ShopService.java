package com.reborn.ec.service;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.ShopInfo;
import com.reborn.ec.dto.ShopView;
import com.reborn.ec.model.Shop;
import com.reborn.ec.model.User;
import com.reborn.ec.repository.ShopRepository;
import com.reborn.ec.repository.UserRepository;
import com.reborn.ec.util.Common;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ShopService {
	private static final Logger logger = LogManager.getLogger(ShopService.class);
	private ShopRepository shopRepository;
	private UserRepository userRepository;
	private final UserService userService;
	private AWSService awsService;

	@Autowired
	public ShopService(ShopRepository shopRepository, UserRepository userRepository, UserService userService, AWSService awsService) {
		this.shopRepository = shopRepository;
		this.userRepository = userRepository;
		this.userService = userService;
		this.awsService = awsService;
	}

	public String getShopId() {
		String userId = userService.getMyId();
		Optional<Shop> shop = shopRepository.findByUserId(userId);
		if (shop.isPresent()) {
			return shop.get().getId();
		} else {
			throw new RuntimeException("shop not found");
		}
	}

	@Transactional
	public BaseResponse<ShopView> createShop(HttpHeaders header, ShopInfo shopInfo) {
		BaseResponse<ShopView> res = new BaseResponse<>();
		Shop shop = new Shop();
		shop.setName(shopInfo.getName());
		shop.setPhone(shopInfo.getPhone());
		shop.setDescription(shopInfo.getDescription());
		shop.setUserId(shopInfo.getUserId());
		// shop.setUserId(userService.getUserIdByEmail(shopInfo.getOwnerEmail()));
		shop.setCompanyId(shopInfo.getCompanyId()); // todo: company table
		shop.setAddressId(shopInfo.getAddressId());
		try {
			shopRepository.save(shop);
			res.setData(new ShopView(shop));
			res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
			res.setMessage("shop.create.success");
		} catch (Exception e) {
			logger.error(e.toString());
			logger.error(e);
			res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
			res.setMessage("shop.create.fail");
		}
		return res;
	}

	public BaseResponse<ShopView> getShopById(HttpHeaders header, String shopId) {
		BaseResponse<ShopView> res = new BaseResponse<>();
		try {
			Optional<Shop> shop = shopRepository.findById(shopId);
			if (shop.isPresent()) {
				res.setData(new ShopView(shop.get()));
				res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
				res.setMessage("shop.get.success");
			} else {
				res.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
				res.setMessage("shop.not.found");
			}
		} catch (Exception e) {
			logger.error(e.toString());
			logger.error(e);
			res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
			res.setMessage("shop.get.fail");
		}
		return res;
	}

	// shop端画面显示店铺信息用
//    public BaseResponse<ShopView> getShopByUserId(HttpHeaders header, String userId) {
//        BaseResponse<ShopView> res = new BaseResponse<>();
//        try{
//            Optional<Shop> shop = shopRepository.findByUserId(userId);
//            if(shop.isPresent()) {
//                res.setData(new ShopView(shop.get()));
//                res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
//                res.setMessage("shop.get.success");
//            } else {
//                res.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
//                res.setMessage("shop.not.found");
//            }
//        } catch (Exception e) {
//            logger.error(e.toString());
//            logger.error(e);
//            res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
//            res.setMessage("shop.get.fail");
//        }
//        return res;
//    }

	public BaseResponse<List<ShopView>> getShopList(HttpHeaders header) {
		BaseResponse<List<ShopView>> res = new BaseResponse<>();
		try {
			List<Shop> shopList = shopRepository.findAll();
			res.setData(ShopView.convert(shopList));
			res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
			res.setMessage("shop.list.success");
		} catch (Exception e) {
			logger.error(e.toString());
			logger.error(e);
			res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
			res.setMessage("shop.list.fail");
		}
		return res;
	}

	public BaseResponse<List<User>> getShopOwnerList(HttpHeaders header) {
		BaseResponse<List<User>> res = new BaseResponse<>();
		try {
			List<String> existedShopOwnerUserIdList = shopRepository.findAllUserIds();
			List<User> availableShopOwnerList = userRepository.findByIdNotIn(existedShopOwnerUserIdList);
			res.setData(availableShopOwnerList);
			res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
			res.setMessage("shopowner.list.success");
		} catch (Exception e) {
			logger.error(e.toString());
			logger.error(e);
			res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
			res.setMessage("shopowner.list.fail");
		}
		return res;
	}

	public BaseResponse<ShopView> updateShop(HttpHeaders header, ShopInfo shopInfo, String shopId) {
		BaseResponse<ShopView> res = new BaseResponse<>();
		try {
			Optional<Shop> shop = shopRepository.findById(shopId);
			if (shop.isPresent()) {
				Shop beforeShop = shop.get();
				BeanUtils.copyProperties(shopInfo, beforeShop, Common.getNullPropertyNames(shopInfo));
				Shop afterShop = shopRepository.save(beforeShop);
				res.setData(new ShopView(afterShop));
				res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
				res.setMessage("shop.update.success");
			} else {
				res.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
				res.setMessage("shop.not.found");
			}

			// TODO:update owner

		} catch (Exception e) {
			logger.error(e.toString());
			logger.error(e);
			res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
			res.setMessage("shop.update.fail");
		}

		return res;
	}

	public BaseResponse<String> deleteShop(HttpHeaders header, String shopId) {
		BaseResponse<String> res = new BaseResponse<>();
		try {
			shopRepository.deleteById(shopId);
			res.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
			res.setMessage("shop.delete.success");
			res.setData("shop.delete.success");
		} catch (Exception e) {
			logger.error(e.toString());
			logger.error(e);
			res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
			res.setMessage("shop.delete.fail");
		}
		return res;
	}

	public BaseResponse<ShopView> getMyShop(HttpHeaders header) {
		BaseResponse<ShopView> res = new BaseResponse<>();
		String shopId;
		try {
			shopId = getShopId();
		} catch (Exception e) {
			logger.error(e.toString());
			logger.error(e);
			res.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
			res.setMessage("shop.id.get.fail");
			return res;
		}
		return getShopById(header, shopId);
	}

	@Transactional
	public BaseResponse<String> uploadImage(HttpHeaders header, MultipartFile shopImage, String shopId) {
		BaseResponse<String> ret = new BaseResponse<>();

		String imageS3Url = null;
		String ext = shopImage.getOriginalFilename().substring(shopImage.getOriginalFilename().lastIndexOf(".") + 1);
		String fileName = shopId + '.' + ext;

		try {
			imageS3Url = awsService.uploadImage(shopImage, "shop-images/" + fileName);
		} catch (Exception e) {
			ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			ret.setMessage("failed to upload image to cloud");
		}

		try {
			shopRepository.updateImage(shopId, imageS3Url);
		} catch (Exception e) {
			ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
			ret.setMessage("failed to upload image to DB");
		}

		ret.setMessage("success to upload image");
		ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
		ret.setData(imageS3Url);
		return ret;
	}

	public String getShopName() {
		String userId = userService.getMyId();
		Optional<Shop> shop = shopRepository.findByUserId(userId);
		if (shop.isPresent()) {
			return shop.get().getName();
		} else {
			throw new RuntimeException("shop not found");
		}
	}
}
