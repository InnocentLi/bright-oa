package com.reborn.ec.dto;

import lombok.Data;

@Data
public class SalesTrackTotalReq {
    String shopID;
    String selectedDate;
}
