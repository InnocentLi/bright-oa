package com.reborn.ec;

public @interface IntegrationComponentScan {

}
