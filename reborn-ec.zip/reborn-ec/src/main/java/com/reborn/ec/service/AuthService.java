package com.reborn.ec.service;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.config.TerminalConfig;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.constant.StatusCode;
import com.reborn.ec.dto.LoginUser;
import com.reborn.ec.dto.UserView;
import com.reborn.ec.i18n.LocalLanguage;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AuthService {

    private static final Logger logger = LogManager.getLogger(AuthService.class);

    private final JwtEncoder jwtEncoder;
    private final LocalLanguage messageSource;
    private final AuthenticationManager authenticationManager;
    private final TerminalConfig terminalConfig;
    private final UserService userService;
    private final ShopService shopService;

    @Autowired
    public AuthService(JwtEncoder jwtEncoder,
                       LocalLanguage messageSource,
                       TerminalConfig terminalConfig,
                       AuthenticationManager authenticationManager,
                       ShopService shopService,
                       UserService userService) {
        this.jwtEncoder = jwtEncoder;
        this.messageSource = messageSource;
        this.authenticationManager = authenticationManager;
        this.terminalConfig = terminalConfig;
        this.shopService = shopService;
        this.userService = userService;
    }

    /**
     * @param authentication
     * @return token
     */
    public String generateToken(Authentication authentication) {
        Instant now = Instant.now();
        long expiry = 60 * 60 * 24 * 2L; // 2 days
        String scope = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(" "));
        JwtClaimsSet claims = JwtClaimsSet.builder()
                .issuer("self")
                .issuedAt(now)
                .expiresAt(now.plusSeconds(expiry))
                .subject(authentication.getName())
                .claim("scope", scope)
                .build();
        return this.jwtEncoder.encode(JwtEncoderParameters.from(claims)).getTokenValue();
    }

    public BaseResponse<UserView> login(HttpHeaders header, LoginUser user) {
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        String terminalType = header.toSingleValueMap().get(HeaderKey.terminalType);
       List<String> acceptRoleMap = terminalConfig.getRoles(terminalType);
        try {
            String encodePassword = user.getPassword();
            Authentication authentication = this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(),encodePassword));
            SecurityContextHolder.getContext().setAuthentication(authentication);

            String token = generateToken(authentication);
//            logger.info("username: {}", SecurityContextHolder.getContext().getAuthentication().getName());


            String userRole = userService.getMyRole();
            String shopId = "";
            try {
                shopId = shopService.getShopId();

            } catch (Exception e) {
                logger.info("shopId  " + shopId);
                logger.info("shopService.getShopId() error  " + e.toString());
                logger.error(e.toString());
                logger.error(e);
            }

            String shopName = "";
            try {
            	shopName = shopService.getShopName();

            } catch (Exception e) {
                logger.info("shopName  " + shopName);
                logger.info("shopService.getShopName() error  " + e.toString());
                logger.error(e.toString());
                logger.error(e);
            }

            logger.info("shopId  " + shopId);
            logger.info("userRole  " + userRole);
            logger.info("shopName  " + shopName);
         if(acceptRoleMap == null ){
            logger.info("acceptRoleMap  " + acceptRoleMap + "not match terminal type");
            return new BaseResponse<UserView>(StatusCode.userDisabled, messageSource.getMessageStr(lang, "terminal.failed"), null);
         }
          if(acceptRoleMap.contains(userRole) == false){
              logger.info("userRole  " + userRole + "not match terminal type");
              return new BaseResponse<UserView>(StatusCode.userDisabled, messageSource.getMessageStr(lang, "user.disable"), null);
          }
            return new BaseResponse<>(String.valueOf(Response.Status.ACCEPTED.getStatusCode()), messageSource.getMessageStr(lang, "success"), new UserView(user.getUsername(), token, userRole,shopId,shopName));
        } catch (DisabledException e) {
            //must be thrown if an account is disabled and the
            return new BaseResponse<UserView>(StatusCode.userDisabled, messageSource.getMessageStr(lang, "user.disable"), null);
        }
        catch(LockedException e){
            //must be thrown if an account is locked and the
            return new BaseResponse<UserView>(StatusCode.userLocked, messageSource.getMessageStr(lang, "user.locked"), null);
        }
        catch(BadCredentialsException e){
            //must be thrown if incorrect credentials are
            return new BaseResponse<UserView>(StatusCode.userUnauthed, messageSource.getMessageStr(lang, "user.username.password.error"), null);
        }
    }

}
