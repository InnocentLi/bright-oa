package com.reborn.ec.dto;

import lombok.Data;

@Data
public class SalesTrackReq {
    String shopID;
    String selectedDate;
}
