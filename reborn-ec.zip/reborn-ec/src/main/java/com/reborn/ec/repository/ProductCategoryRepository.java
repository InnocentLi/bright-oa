package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reborn.ec.model.ProductCategory;

public interface ProductCategoryRepository extends JpaRepository<ProductCategory, String> {
}