package com.reborn.ec.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.LoginUser;
import com.reborn.ec.dto.UserView;
import com.reborn.ec.service.AuthService;


@RestController
public class AuthController {

    private final AuthService authService;
    private final Logger logger = LogManager.getLogger(AuthController.class);

    @Autowired
    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public BaseResponse<UserView> login(@RequestHeader HttpHeaders header, @RequestBody LoginUser user) {

        return authService.login(header, user);
    }
    @GetMapping("/healthy")
    public String gethealthy() {
        logger.info("healthy: OK");
        return " get healthy OK";
    }
    @PostMapping("/healthy")
    public String posthealthy() {
        logger.info("post healthy: OK");
        return "post healthy OK";
    }




}
