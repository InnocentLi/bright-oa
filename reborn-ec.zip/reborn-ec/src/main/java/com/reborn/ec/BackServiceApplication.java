package com.reborn.ec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import springfox.documentation.oas.annotations.EnableOpenApi;

@EnableOpenApi
@SpringBootApplication
@EnableAsync
public class BackServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackServiceApplication.class, args);
	}

}
