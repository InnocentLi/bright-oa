
package com.reborn.ec.dto;

import lombok.Data;

@Data
public class AdvertismentReq {
    String title;
    String subtitle;
    String content;
    String advertismentID;
}