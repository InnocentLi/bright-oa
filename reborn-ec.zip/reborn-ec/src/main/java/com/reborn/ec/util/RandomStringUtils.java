package com.reborn.ec.util;

public class RandomStringUtils {
    public static String getRandomString(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        int randomNum;
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            randomNum = (int) (Math.random() * base.length());
            sb.append(base.charAt(randomNum));
        }
        return sb.toString();
    }

}
