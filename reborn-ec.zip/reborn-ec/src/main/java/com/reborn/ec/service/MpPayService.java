package com.reborn.ec.service;

import jakarta.ws.rs.core.Response;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestHeader;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.constant.RoleType;
import com.reborn.ec.dto.ChangePasswordDto;
import com.reborn.ec.dto.SignupUser;
import com.reborn.ec.dto.UpdatePasswordDto;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.User;
import com.reborn.ec.model.UserToken;
import com.reborn.ec.repository.UserRepository;
import com.reborn.ec.repository.UserTokenRepository;
import com.reborn.ec.util.Common;

import java.util.Optional;

@Service
public class MpPayService {

    private UserRepository userRepository;
    private LocalLanguage messageSource;
    private PasswordEncoder passwordEncoder;

    private final Logger logger = org.apache.logging.log4j.LogManager.getLogger(MpPayService.class);


    @Autowired
    public MpPayService(PasswordEncoder passwordEncoder, UserRepository userRepository, LocalLanguage messageSource, EmailService emailService, UserTokenRepository userTokenRepository, UserTokenService userTokenService) {
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
        this.messageSource = messageSource;
    }


    public BaseResponse<User> mpPayNotification(@RequestHeader HttpHeaders header,String notification ) {

        logger.info("mpPayNotification notification ====",notification);
        BaseResponse<User> ret = new BaseResponse<>();
        String retCodeStr = String.valueOf(Response.Status.OK.getStatusCode());
        ret.setCode(retCodeStr.toString());
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);

        String hello = messageSource.getMessageStr(lang, "hello");
        ret.setMessage(hello);
        return ret;
    }

    
}
