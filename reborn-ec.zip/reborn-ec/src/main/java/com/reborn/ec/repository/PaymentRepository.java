package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.reborn.ec.model.Payment;

import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, String> {
    @Modifying(clearAutomatically = true)
    @Query("update Payment p set p.orderId = ?2 where p.id = ?1")
    void updateOrderId(String paymentId, String orderId);

    @Query("SELECT p FROM Payment p WHERE p.id = ?1 AND p.deleteFlag = 0")
    Optional<Payment> findById(String id);
}