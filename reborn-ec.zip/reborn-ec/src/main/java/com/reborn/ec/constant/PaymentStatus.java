package com.reborn.ec.constant;

public enum PaymentStatus {
    CREATED("created", (byte) 0),
    PAID("paid", (byte) 1),
    PENDING("pending", (byte) 2),
    CANCELLED("cancelled", (byte) 3);



    private final String status;
    private final byte b;

    PaymentStatus(String status, byte b) {
        this.status = status;
        this.b = b;
    }

    public byte getByteValue() {
        return b;
    }
}
