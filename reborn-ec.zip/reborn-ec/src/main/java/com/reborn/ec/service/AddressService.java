package com.reborn.ec.service;


import jakarta.ws.rs.core.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.Address;
import com.reborn.ec.repository.AddressRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AddressService {
    private final AddressRepository addressRepository;
    private final LocalLanguage messageSource;

    private final UserService userService;

    @Autowired
    public AddressService(AddressRepository addressRepository, LocalLanguage messageSource, UserService userService) {
        this.addressRepository = addressRepository;
        this.messageSource = messageSource;
        this.userService = userService;
    }

    private Address newAddress(Address address) {
        Address a = new Address();
        a.setId("address"+ System.currentTimeMillis());
        a.setEntityId(userService.getMyId());
        a.setPostalCode(address.getPostalCode());
        a.setPrefecture(address.getPrefecture());
        a.setWard(address.getWard());
        a.setDistrict(address.getDistrict());
        a.setBuildingAndUnitNumber(address.getBuildingAndUnitNumber());
        a.setDeleteFlag((byte) 0);
        return a;
    }
// 创建住所
public BaseResponse<Address> createAddress(HttpHeaders header, Address address){
    BaseResponse<Address> ret = new BaseResponse<>();
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);

    Address a = newAddress(address);

    try{
        ret.setData(addressRepository.save(a));
        ret.setCode(String.valueOf(Response.Status.CREATED.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "address.created"));
    }catch (Exception e){
        ret.setCode(String.valueOf(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "address.create.failed"));
    }
    return ret;
}

// 更新住所
public BaseResponse<Address> updateAddress(HttpHeaders header, Address address){
    BaseResponse<Address> ret = new BaseResponse<>();
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
    if(address.getId()!= null && addressRepository.findById(address.getId()) != null){
        ret.setCode(String.valueOf(Response.Status.RESET_CONTENT.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "address.reseted"));
        if(address.getPostalCode()!=null){
            addressRepository.setPostalCode(address.getPostalCode(), address.getId());
        }
        if(address.getPrefecture()!=null){
            addressRepository.setPrefecture(address.getPrefecture(), address.getId());
        }
        if(address.getWard()!=null){
            addressRepository.setWard(address.getWard(), address.getId());
        }
        if(address.getDistrict()!=null){
            addressRepository.setDistrict(address.getDistrict(), address.getId());
        }
        if(address.getBuildingAndUnitNumber()!=null){
            addressRepository.setBuildingAndUnitNumber(address.getBuildingAndUnitNumber(), address.getId());
        }
        Optional<Address> addOpt = addressRepository.findById(address.getId());
        if(addOpt.isPresent()){
            ret.setData(addOpt.get());
        }
        return ret;
    }
    ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
    ret.setMessage(messageSource.getMessageStr(lang, "address.unfound"));

    return ret;
}

// 获取单个住所信息
public BaseResponse<Address> getAddress(HttpHeaders header, String id){
    BaseResponse<Address> ret = new BaseResponse<>();
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
    if (addressRepository.findById(id) != null){
        ret.setCode(String.valueOf(Response.Status.FOUND.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "address.found"));
        ret.setData(addressRepository.findById(id).get());
        return ret;
    }
    ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
    ret.setMessage(messageSource.getMessageStr(lang, "address.unfound"));

    return ret;
}

// 删除地址
public BaseResponse<Address> deleteAddress(HttpHeaders header, Address address){
    BaseResponse<Address> ret = new BaseResponse<>();
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
    if(address.getId()!= null && addressRepository.findById(address.getId()) != null){
        ret.setCode(String.valueOf(Response.Status.RESET_CONTENT.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "address.deleted"));
        addressRepository.deleteAddress(address.getId());
        ret.setData(addressRepository.findById(address.getId()).get());
        return ret;
    }
    ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
    ret.setMessage(messageSource.getMessageStr(lang, "address.unfound"));

    return ret;
}


// 获取住所列表
public BaseResponse<List<Address>> getMyAddressList(HttpHeaders header){
    BaseResponse<List<Address>> ret = new BaseResponse<>();
    String userId = userService.getMyId();
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);

    try {
        List<Address> addressList = addressRepository.findByEntityId(userId);
        ret.setCode(String.valueOf(Response.Status.FOUND.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "address.found"));
        ret.setData(addressList);
    }
    catch (Exception e){
        ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "address.unfound"));
    }
    return ret;
}


}
