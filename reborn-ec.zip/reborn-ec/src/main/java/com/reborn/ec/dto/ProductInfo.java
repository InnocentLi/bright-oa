package com.reborn.ec.dto;

import com.reborn.ec.model.Product;

import lombok.Data;

@Data
public class ProductInfo {
    private Product product;
    private Boolean isFavorited;
}
