package com.reborn.ec.constant;

import java.util.HashMap;
import java.util.Map;

public enum UserStatus {
    ACTIVE("ACTIVE", (byte) 0),
    BLOCKED("BLOCKED" ,(byte) 1);


    private final String status;
    private final byte b;

    UserStatus(String status, byte b) {
        this.status = status;
        this.b = b;
    }

    public static Map<Integer, String> getAllStatus() {
        Map<Integer, String> map = new HashMap<>();
        for (UserStatus status : UserStatus.values()) {
            map.put((int) status.b, status.status);
        }
        return map;

    }

    public String getStatus() {
        return status;
    }
    public byte getB() {
        return b;
    }
}

