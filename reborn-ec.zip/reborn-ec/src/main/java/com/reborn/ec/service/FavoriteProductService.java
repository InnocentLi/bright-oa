package com.reborn.ec.service;

import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.dto.FavoriteProductInfo;
import com.reborn.ec.dto.FavoriteProductReq;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.FavoriteProduct;
import com.reborn.ec.repository.FavoriteProductRepository;
import com.reborn.ec.repository.ProductRepository;
import com.reborn.ec.repository.ShopRepository;
import com.reborn.ec.repository.UserRepository;
import com.reborn.ec.util.Common;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@Slf4j
public class FavoriteProductService {

    private final ProductRepository productRepository;
    private final ShopRepository shopRepository;
    private final UserService userService;

    private final FavoriteProductRepository FavoriteProductRepository;

    private final LocalLanguage messageSource;

    // private final UserService userService;s
    private final Logger logger = org.apache.logging.log4j.LogManager.getLogger(FavoriteProductService.class);

    @Autowired
    public FavoriteProductService(  ProductRepository productRepository, 
                            UserRepository userRepository, 
                            FavoriteProductRepository FavoriteProductRepository,
                            ShopRepository shopRepository,
                            LocalLanguage messageSource,
                            UserService userService) {
        this.productRepository = productRepository;
        this.userService = userService;
        this.FavoriteProductRepository = FavoriteProductRepository;
        this.shopRepository = shopRepository;
        this.messageSource = messageSource;
    }

    public BaseResponse<List<FavoriteProductInfo>> listFavoriteProduct(HttpHeaders header) {
        BaseResponse<List<FavoriteProductInfo>> ret = new BaseResponse<>();
        List<FavoriteProductInfo> favoriteProductInfoList = new ArrayList<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        try{
            String userId = userService.getMyId();
            List<FavoriteProduct> FavoriteList = FavoriteProductRepository.findByUserId(userId);
            for (FavoriteProduct favoriteProduct : FavoriteList) {
                FavoriteProductInfo favoriteProductInfo = new FavoriteProductInfo();
                favoriteProductInfo.setFavoriteProduct(favoriteProduct);
                favoriteProductInfo.setShopName(shopRepository.findById(favoriteProduct.getShopId()).get().getName());
                favoriteProductInfoList.add(favoriteProductInfo);
            }
            ret.setData(favoriteProductInfoList);
            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            
            ret.setMessage(messageSource.getMessageStr(lang, "user.get.Favorite.list.success"));
        } catch (Exception e) {
            logger.error(e.toString());
            logger.error(e);
            ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "user.get.Favorite.list.failed"));
        }
        return ret;
    }

    public BaseResponse<FavoriteProduct> FavoriteProduct(HttpHeaders header, FavoriteProductReq product) {
        BaseResponse<FavoriteProduct> ret = new BaseResponse<>();
        String productId = product.getProductId();
        String userId = userService.getMyId();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
        ret.setMessage(messageSource.getMessageStr(lang, "user.get.Favorite.failed"));
        try{
            Optional<FavoriteProduct> fOpt = FavoriteProductRepository.findByUserIdAndProductId(userId, productId);
            FavoriteProduct FavoriteProduct;
            if(fOpt.isPresent()){
                FavoriteProduct = fOpt.get();
                if(FavoriteProduct == null){
                    FavoriteProduct = new FavoriteProduct();
                    BeanUtils.copyProperties(product, FavoriteProduct,Common.getNullPropertyNames(product));
                    FavoriteProduct.setUserId(userId);
                    FavoriteProduct.setProductId(productId);
                    ret.setMessage(messageSource.getMessageStr(lang, "user.get.Favorite.success"));
                }
                else{
                    if(FavoriteProduct.getDeleteFlag()== 0){
                        FavoriteProduct.setDeleteFlag((byte)1);
                        ret.setMessage(messageSource.getMessageStr(lang, "user.get.Favorite.cancelled.success"));
                    }
                    else{
                        FavoriteProduct.setDeleteFlag((byte)0);
                        ret.setMessage(messageSource.getMessageStr(lang, "user.get.Favorite.success"));
                    }
                    FavoriteProduct.setUserId(userId);
                    FavoriteProduct.setProductId(productId);
                }
                FavoriteProductRepository.save(FavoriteProduct);
                ret.setData(FavoriteProduct);
                ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
                
            }
            else{
                if(fOpt.isEmpty()){
                    FavoriteProduct = new FavoriteProduct();
                    BeanUtils.copyProperties(product, FavoriteProduct,Common.getNullPropertyNames(product));
                    FavoriteProduct.setUserId(userId);
                    FavoriteProduct.setProductId(productId);
                    FavoriteProductRepository.save(FavoriteProduct);
                    ret.setData(FavoriteProduct);
                    ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
                    ret.setMessage(messageSource.getMessageStr(lang, "user.get.Favorite.success"));
                }
            }
        
        } catch (Exception e) {
            logger.error(e.toString());
            logger.error(e);
        }
        return ret;
    }
}
