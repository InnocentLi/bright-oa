package com.reborn.ec.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Entity
@DynamicUpdate(true)
@Table(name = "faq", schema = "rebornecdb")
public class FAQ {

    @Id
    @Column(name = "id")
    @GeneratedValue(generator="system-uuid")
    @GenericGenerator(name="system-uuid", strategy = "uuid")
    private String id;

    @Basic
    @Column(name = "title")
    private String title;

    @Basic
    @Column(name = "question")
    private String question;

    @Basic
    @Column(name = "answer")
    private String answer;

    @Basic
    @Column(name = "delete_flag", columnDefinition = "TINYINT(1) NOT NULL DEFAULT 0")
    private Byte deleteFlag;
    @Basic
    @Column(name = "created_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @CreationTimestamp
    private Timestamp createdAt;
    @Basic
    @Column(name = "updated_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    @UpdateTimestamp
    private Timestamp updatedAt;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        FAQ faq = (FAQ) o;
        return id != null && Objects.equals(id, faq.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
    
}
