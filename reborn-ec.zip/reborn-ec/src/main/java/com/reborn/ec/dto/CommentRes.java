package com.reborn.ec.dto;

import lombok.Data;

@Data
public class CommentRes {
    String userName;
    String commentContent;
    String commentID;
}
