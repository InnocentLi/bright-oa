package com.reborn.ec.service;

import jakarta.ws.rs.core.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.QA;
import com.reborn.ec.repository.QARepository;

import java.util.List;

@Service
public class QAService {

  private final QARepository qaRepository;
  private final LocalLanguage messageSource;

  private final UserService userService;

  @Autowired
  public QAService(QARepository qaRepository, LocalLanguage messageSource, UserService userService) {
    this.qaRepository = qaRepository;
    this.messageSource = messageSource;
    this.userService = userService;
  }

  private QA newQA(QA qa) {
    QA q = new QA();
    q.setContact(qa.getContact());
    q.setQuestion(qa.getQuestion());
    q.setAnswer("");
    q.setUserName(userService.getMyName());
    q.setDeleteFlag((byte) 0);
    return q;
  }

  public BaseResponse<QA> createQA(HttpHeaders header, QA qa) {
    BaseResponse<QA> ret = new BaseResponse<>();
    QA q = newQA(qa);
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
    try {
      qaRepository.save(q);
      ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
      ret.setMessage(messageSource.getMessageStr(lang, "success"));
    } catch (Exception e) {
      ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
      ret.setMessage("failed to create qa");
      ret.setMessage(messageSource.getMessageStr(lang, "success"));
    }
    return ret;
  }

  // 获取QA列表
  public BaseResponse<List<QA>> getQAList(HttpHeaders header) {
    BaseResponse<List<QA>> ret = new BaseResponse<>();
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
    if (qaRepository.findAll() != null) {
      ret.setCode(String.valueOf(Response.Status.FOUND.getStatusCode()));
      ret.setMessage(messageSource.getMessageStr(lang, "QA.found"));
      ret.setData(qaRepository.findAll());
      return ret;
    }
    ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
    ret.setMessage(messageSource.getMessageStr(lang, "QA.unfound"));

    return ret;
  }

  public BaseResponse<QA> deleteQA(HttpHeaders header, QA qa) {
    BaseResponse<QA> ret = new BaseResponse<>();
    String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
    if (qa.getId() != null && qaRepository.findById(qa.getId()) != null) {
      ret.setCode(String.valueOf(Response.Status.RESET_CONTENT.getStatusCode()));
      ret.setMessage(messageSource.getMessageStr(lang, "QA.deleted"));
      qaRepository.deleteQA(qa.getId());
      // ret.setData(qaRepository.findById(qa.getId()).get());
      return ret;
    }
    ret.setCode(String.valueOf(Response.Status.NOT_FOUND.getStatusCode()));
    ret.setMessage(messageSource.getMessageStr(lang, "QA.unfound"));

    return ret;
  }
}
