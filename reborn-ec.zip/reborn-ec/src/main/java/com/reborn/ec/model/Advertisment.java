package com.reborn.ec.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;


@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Entity
@DynamicUpdate(true)
@Table(name = "advertisment", schema = "rebornecdb")
public class Advertisment {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator="system-uuid")
    @GenericGenerator(name="system-uuid", strategy = "uuid")
    private String id;

    @Basic
    @Column(name = "title")
    private String title;

    @Basic
    @Column(name = "subtitle")
    private String subtitle;

    @Basic
    @Column(name = "content")
    private String content;

    @Basic
    @Column(name = "cover_image")
    private String coverImage;

    @Basic
    @Column(name = "delete_flag", columnDefinition = "TINYINT(1) NOT NULL DEFAULT 0")
    private Byte deleteFlag;
    @Basic
    @Column(name = "created_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @CreationTimestamp
    private Timestamp createdAt;
    @Basic
    @Column(name = "updated_at", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    @UpdateTimestamp
    private Timestamp updatedAt;

    // @Override
    // public boolean equals(Object o) {
    //     if (this == o) return true;
    //     if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
    //     Advertisment advertisment = (Advertisment) o;
    //     return id != null && Objects.equals(id, advertisment.id);
    // }

    // @Override
    // public int hashCode() {
    //     return getClass().hashCode();
    // }
}
