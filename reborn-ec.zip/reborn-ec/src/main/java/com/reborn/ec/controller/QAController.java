package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.model.QA;
import com.reborn.ec.service.QAService;

import java.util.List;

@RestController
public class QAController {
    private final QAService qaService;


    @Autowired
    public QAController(QAService qaService) {
        this.qaService = qaService;
    }

    /**
     * 创建qa
     * @param header
     * @param qa
     * @return qa信息
     */
    @PostMapping("/qa/create")
    public BaseResponse<QA> createQA(@RequestHeader HttpHeaders header, @RequestBody QA qa) {
        return qaService.createQA(header, qa);
    }

    /**
     * 查看所有qa
     * @param header
     * @return qa列表
     */
    @GetMapping("/qa/list")
    public BaseResponse<List<QA>> getQAList(@RequestHeader HttpHeaders header) {
        return qaService.getQAList(header);
    }

    /**
     * 删除qa
     * @param header
     * @return qa信息
     */
    @PostMapping("/qa/delete")
    public BaseResponse<QA> deleteQA(@RequestHeader HttpHeaders header, @RequestBody QA qa) {
        return qaService.deleteQA(header, qa);
    }

}
