package com.reborn.ec.controller;

import com.reborn.ec.service.CommentService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.CommentReq;
import com.reborn.ec.dto.CommentRes;


@RestController
public class CommentController {
    
    private final CommentService service;

    @Autowired
    public CommentController(CommentService service) {
        this.service = service;
    }

    //商品コメント 追加
     @PostMapping("/comment/create")
     public BaseResponse<CommentRes> createComment(@RequestHeader HttpHeaders header, @RequestBody CommentReq comment) {
         return service.createComment(header, comment);
     }

     //商品コメント リスト
     @PostMapping("/comment/list")
     public BaseResponse<List<CommentRes>> listComment(@RequestHeader HttpHeaders header, @RequestBody CommentReq comment) {
         return service.listComment(header, comment);
     }
}
