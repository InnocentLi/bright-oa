package com.reborn.ec.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.constant.StatusCode;
import com.reborn.ec.dto.AdvertismentReq;
import com.reborn.ec.dto.AdvertismentRes;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.model.Advertisment;
import com.reborn.ec.repository.AdvertiseRepository;
import jakarta.ws.rs.core.Response;

@Service
public class AdvertiseService {

     private final AdvertiseRepository advertiseRepository;
     private final LocalLanguage messageSource;
     private static final Logger logger = LogManager.getLogger(AdvertiseService.class);

     private final UserService userService;

     private AWSService awsService;

     @Autowired
     public AdvertiseService(AdvertiseRepository advertiseRepository, LocalLanguage messageSource, AWSService awsService, UserService userService) {
          this.advertiseRepository = advertiseRepository;
          this.messageSource = messageSource;
          this.userService = userService;
          this.awsService = awsService;
     }


    // 宣伝展示：新規・変更・削除
    // 向け対象：全部

     // 宣伝展示：新規
     public BaseResponse<AdvertismentRes> createAdvertisment(HttpHeaders header, AdvertismentReq advertisment) {
          BaseResponse<AdvertismentRes> ret = new BaseResponse<>();
          String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
          String userID = userService.getMyId();
          String userName = userService.getMyName();
          Advertisment newAdvertisment = new Advertisment();
          newAdvertisment.setTitle(advertisment.getTitle());
          newAdvertisment.setSubtitle(advertisment.getSubtitle());
          newAdvertisment.setContent(advertisment.getContent());
          newAdvertisment.setDeleteFlag((byte)0);
          newAdvertisment = advertiseRepository.save(newAdvertisment);

          AdvertismentRes retItem= new AdvertismentRes();
          retItem.setAdvertismentID(newAdvertisment.getId());
          retItem.setContent(newAdvertisment.getContent());
          retItem.setTitle(newAdvertisment.getTitle());
          retItem.setSubtitle(newAdvertisment.getSubtitle());

          ret.setData(retItem);
          ret.setMessage(messageSource.getMessageStr(lang, "success"));
          return ret;
     }
     // 宣伝展示：変更
     public BaseResponse<AdvertismentRes> changeAdvertisment(HttpHeaders header, AdvertismentReq advertisment) {
          BaseResponse<AdvertismentRes> ret = new BaseResponse<>();
          String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
          String userID = userService.getMyId();
          String userName = userService.getMyName();
          Optional<Advertisment> advertismentOpt = advertiseRepository.findById(advertisment.getAdvertismentID());

          if(advertismentOpt.isPresent()){
               Advertisment changeAdvertisment = advertismentOpt.get();
               changeAdvertisment.setTitle(advertisment.getTitle());
               changeAdvertisment.setSubtitle(advertisment.getSubtitle());
               changeAdvertisment.setContent(advertisment.getContent());
               changeAdvertisment.setId(advertisment.getAdvertismentID());
               changeAdvertisment = advertiseRepository.save(changeAdvertisment);

               AdvertismentRes retItem= new AdvertismentRes();
               retItem.setAdvertismentID(changeAdvertisment.getId());
               retItem.setContent(changeAdvertisment.getContent());
               retItem.setTitle(changeAdvertisment.getTitle());
               retItem.setSubtitle(changeAdvertisment.getSubtitle());
               ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
               ret.setMessage(messageSource.getMessageStr(lang, "success"));
               ret.setData(retItem);
               return ret;
          }
          ret.setMessage(messageSource.getMessageStr(lang, "failed"));
          ret.setCode(StatusCode.failed);

          return ret;
     }
     // 宣伝展示：削除

     public BaseResponse<AdvertismentRes> deleteAdvertisment( HttpHeaders header, AdvertismentReq advertisment) {
          BaseResponse<AdvertismentRes> ret = new BaseResponse<>();
          String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
          String userID = userService.getMyId();
          String userName = userService.getMyName();
          int deletecount = advertiseRepository.deleteAdvertismentByID(advertisment.getAdvertismentID());
          if(deletecount < 1){
               ret.setCode(StatusCode.deletedFailed);
               ret.setMessage(messageSource.getMessageStr(lang, "deleted.failed"));
               return ret;
          }
          ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
          AdvertismentRes retItem= new AdvertismentRes();
          retItem.setAdvertismentID(advertisment.getAdvertismentID());
          retItem.setContent(advertisment.getContent());
          retItem.setTitle(advertisment.getTitle());
          retItem.setSubtitle(advertisment.getSubtitle());

          ret.setData(retItem);
          ret.setMessage(messageSource.getMessageStr(lang, "success"));
          return ret;
     }

     // 宣伝展示：list
     public BaseResponse<List<AdvertismentRes>> listAdvertisment( HttpHeaders header, AdvertismentReq advertisment) {
          BaseResponse<List<AdvertismentRes>> ret = new BaseResponse<>();
          String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
          String userID = userService.getMyId();
          String userName = userService.getMyName();
          List<Advertisment> advertists = advertiseRepository.findAll();
          List<AdvertismentRes> retList = new ArrayList<AdvertismentRes>();
          for (Advertisment item : advertists) {
               AdvertismentRes retItem= new AdvertismentRes();
               retItem.setAdvertismentID(item.getId());
               retItem.setContent(item.getContent());
               retItem.setTitle(item.getTitle());
               retItem.setSubtitle(item.getSubtitle());
               retItem.setCoverImg(item.getCoverImage());
               retList.add(retItem);
          }

          ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
          ret.setMessage(messageSource.getMessageStr(lang, "success"));
          ret.setData(retList);
          return ret;
     }

     @Transactional
     public BaseResponse<String> uploadAdvertismentCoverImage(HttpHeaders header, MultipartFile image, String advertismentID) {
          BaseResponse<String> ret = new BaseResponse<>();
          Optional<Advertisment> advOpt = advertiseRepository.findById(advertismentID);
          if(advOpt.isPresent() == false) {
               ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
               ret.setMessage("Advertisment does not exist");
               return ret;
          }

          String imageS3Url = null;
          String ext = image.getOriginalFilename().substring(image.getOriginalFilename().lastIndexOf(".")+1);
          String fileName = advertismentID + '.' + ext;

          try{
               imageS3Url = awsService.uploadImage(image, "advertisment-images/"+fileName);
          } catch (Exception e) {
               ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
               ret.setMessage("Advertisment failed to upload image to cloud");
               return ret;
          }

          try{
               advertiseRepository.updateImage(advertismentID, imageS3Url);
          } catch (Exception e) {
               ret.setCode(String.valueOf(Response.Status.BAD_REQUEST.getStatusCode()));
               ret.setMessage("Advertisment failed to upload image to DB");
               return ret;
          }

          ret.setMessage("success to upload image");
          ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
          ret.setData(imageS3Url);
          return ret;
     }
}
