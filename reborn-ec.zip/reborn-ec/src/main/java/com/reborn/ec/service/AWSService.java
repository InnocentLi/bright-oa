package com.reborn.ec.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

@Service
public class AWSService {
    private final AmazonS3 amazonS3;

    private final PasswordEncoder passwordEncoder;
    private static final Logger logger = LogManager.getLogger(AWSService.class);

    @Value("${cloud.aws.s3.bucket}")
    private String bucketName;
    @Autowired

    public AWSService(AmazonS3 amazonS3, PasswordEncoder passwordEncoder) {
        this.amazonS3 = amazonS3;
        this.passwordEncoder = passwordEncoder;
    }

//    public String generatePreSignedUrl(String fileName, String bucketName, HttpMethod httpMethod) {
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(new Date());
//        calendar.add(Calendar.MINUTE, 10); //validity of 10 minutes
//
//        try{
//            URL url = amazonS3.generatePresignedUrl(bucketName, fileName, calendar.getTime(), httpMethod);
//            return url.toString();
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }



    public String uploadImage(MultipartFile productImage, String fileName) {
        InputStream inputStream;
        ObjectMetadata objectMetadata = new ObjectMetadata();

        try {
            inputStream = productImage.getInputStream();
            objectMetadata.setContentLength(productImage.getSize());
        } catch (Exception e) {
            logger.error(e.toString());
            logger.error(e);
            throw new RuntimeException("Error occurred while creating input stream for the file", e);
        }

        String encryptedFileName = fileName;//passwordEncoder.encode(fileName);

        // upload image to S3
        String imageUrl;
        try {
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, fileName, inputStream, objectMetadata);
            amazonS3.putObject(putObjectRequest);
            imageUrl = amazonS3.getUrl(bucketName, encryptedFileName).toString();
        } catch (Exception e) {
            logger.error(e.toString());
            logger.error(e);
            throw new RuntimeException("Error uploading file to S3");
        }
        return imageUrl;
    }
}
