package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.User;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface UserRepository extends JpaRepository<User, String> {
    @Query("select u from User u where u.id = ?1 and u.deleteFlag = 0")
    Optional<User> findById(String id);

    @Query("select u from User u where u.username = ?1 and u.deleteFlag = 0")
    Optional<User> findByUsername(String username);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE User SET username = :username WHERE id = :id")
    void setUsername(@Param("username") String username,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE User SET phone = :phone WHERE id = :id")
    void setPhone(@Param("phone") String phone,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE User SET email = :email WHERE id = :id")
    void setEmail(@Param("email") String email,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE User SET password = :password WHERE id = :id")
    void updatePassword(@Param("password") String password,@Param("id") String id);

    @Query("select u from User u where u.deleteFlag = 0 and u.email = ?1")
    User findByEmail(String email);

    @Query("select u.roleId from User u where u.deleteFlag = 0 and u.id = ?1")
    String findRoleIdById(String id);

    @Query("select u.id from User u where u.deleteFlag = 0 and u.username = ?1")
    String findIdByUsername(String username);

    @Query("select u.id from User u where u.deleteFlag = 0 and u.email = ?1")
    String findIdByEmail(String userEmail);

    @Query("select u from User u where u.deleteFlag = 0")
    List<User> findAll();

    @Query("select u from User u where u.roleId = 'SHOPOWNER' and u.deleteFlag = 0 and u.id not in ?1")
    public List<User> findByIdNotIn(List<String> existedShopOwnerUserIdList);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE User SET deleteFlag = 1 WHERE id = :id")
    void deleteById(String id);

    @Query("select count(u)>0 from User u where u.deleteFlag = 0 and u.username = ?1")
    boolean existsByUsername(String username);

    @Query("select count(u)>0  from User u where u.deleteFlag = 0 and u.email = ?1")
    boolean existsByEmail(String email);

    @Query("select u.username from User u where u.deleteFlag = 0 and u.id = :userId")
    String findUsernameById(String userId);
}