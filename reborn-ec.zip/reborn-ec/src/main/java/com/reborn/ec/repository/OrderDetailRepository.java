package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.reborn.ec.model.OrderDetail;

import java.util.List;

public interface OrderDetailRepository extends JpaRepository<OrderDetail, String> {

    @Query("select od from OrderDetail od where od.orderId = ?1 and od.deleteFlag = 0")
    List<OrderDetail> findByOrderId(String orderId);
}