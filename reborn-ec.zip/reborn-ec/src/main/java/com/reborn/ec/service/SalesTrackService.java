package com.reborn.ec.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.constant.HeaderKey;
import com.reborn.ec.dto.SalesTrackMonthReq;
import com.reborn.ec.dto.SalesTrackReq;
import com.reborn.ec.dto.SalesTrackRes;
import com.reborn.ec.dto.SalesTrackTotalReq;
import com.reborn.ec.i18n.LocalLanguage;
import com.reborn.ec.repository.AddressRepository;
import com.reborn.ec.repository.OrderDetailRepository;
import com.reborn.ec.repository.OrderRepository;
import com.reborn.ec.repository.PaymentRepository;
import com.reborn.ec.repository.ProductRepository;
import com.reborn.ec.repository.ShopRepository;
import com.reborn.ec.repository.UserRepository;
import com.reborn.ec.util.DateUtil;

import jakarta.ws.rs.core.Response;

@Service
public class SalesTrackService {
    private final Logger logger = org.apache.logging.log4j.LogManager.getLogger(SalesTrackService.class);

    private final OrderRepository orderRepository;
	private final UserService userService;
	private final OrderDetailRepository orderDetailRepository;
	private final ProductRepository productRepository;
	private final AddressRepository addressRepository;
	private final PaymentRepository paymentRepository;
	private final UserRepository userRepository;
	private final ShopRepository shopRepository;
	private final ShipService shipService;
	private final PaymentService paymentService;
	private final LocalLanguage messageSource;
	private final ShopService shopService;

    @Autowired
	public SalesTrackService(   OrderRepository orderRepository, 
                                UserService userService, 
                                OrderDetailRepository orderDetailRepository, 
                                ProductRepository productRepository, 
                                AddressRepository addressRepository, 
                                PaymentRepository paymentRepository, 
                                UserRepository userRepository, 
                                ShopRepository shopRepository, 
                                ShipService shipService, 
                                PaymentService paymentService, 
                                ShopService shopService, 
                                LocalLanguage messageSource) {
		this.orderRepository = orderRepository;
		this.userService = userService;
		this.orderDetailRepository = orderDetailRepository;
		this.productRepository = productRepository;
		this.addressRepository = addressRepository;
		this.paymentRepository = paymentRepository;
		this.userRepository = userRepository;
		this.shopRepository = shopRepository;
		this.shipService = shipService;
		this.paymentService = paymentService;
		this.messageSource = messageSource;
		this.shopService = shopService;
	}

    // 週、月、年額
    public BaseResponse<SalesTrackRes> monthTotal( HttpHeaders header, SalesTrackMonthReq salesTrack) {
        BaseResponse<SalesTrackRes> ret = new BaseResponse<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        try {
            String dateStr = salesTrack.getSelectedDate();
            if( dateStr == null || dateStr.length()== 0){
                dateStr = new SimpleDateFormat("yyyy-MM-dd").format(new Date()).toString();
            }
            DateUtil.parseCalendar(dateStr);

            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "success"));
        } catch (Exception e) {
            // TODO: handle exception
            ret.setCode(String.valueOf(Response.Status.PERMANENT_REDIRECT.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "faileds"));
        }
        return ret;
    }

    // 月的累计金额
    public BaseResponse<SalesTrackRes> totalByMonth( HttpHeaders header, SalesTrackTotalReq salesTrack) {
        BaseResponse<SalesTrackRes> ret = new BaseResponse<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        try {
            String dateStr = salesTrack.getSelectedDate();
            if( dateStr == null || dateStr.length()== 0){
                dateStr = new SimpleDateFormat("yyyy-MM-dd").format(new Date()).toString();
            }
            DateUtil.parseCalendar(dateStr);

            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "success"));
        } catch (Exception e) {
            // TODO: handle exception
            ret.setCode(String.valueOf(Response.Status.PERMANENT_REDIRECT.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "faileds"));
        }
        return ret;
    }
    
    // 売り上げ配列（２０まで）
    public BaseResponse<SalesTrackRes> listTopSalesProduct( HttpHeaders header, SalesTrackReq salesTrack) {
        BaseResponse<SalesTrackRes> ret = new BaseResponse<>();
        String lang = header.toSingleValueMap().get(HeaderKey.localLanguage);
        try {
            String dateStr = salesTrack.getSelectedDate();
            if( dateStr == null || dateStr.length()== 0){
                dateStr = new SimpleDateFormat("yyyy-MM-dd").format(new Date()).toString();
            }
            DateUtil.parseCalendar(dateStr);

            ret.setCode(String.valueOf(Response.Status.OK.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "success"));
        } catch (Exception e) {
            // TODO: handle exception
            ret.setCode(String.valueOf(Response.Status.PERMANENT_REDIRECT.getStatusCode()));
            ret.setMessage(messageSource.getMessageStr(lang, "faileds"));
        }
        return ret;
    }

}
