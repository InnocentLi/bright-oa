package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.Account;
import com.reborn.ec.model.User;
import com.reborn.ec.service.AccountService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@RolesAllowed("ROLE_ADMIN")
public class AccountController {

    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    /**
     * 用户列表
     * @return users
     */
    @GetMapping("/admin/account/list")
    public BaseResponse<List<User>> accountList(@RequestHeader HttpHeaders header) {
        return this.accountService.getAccountList(header);
    }

    /**
     * 创建用户
     * @param account
     * @return user
     */
    @PostMapping("/admin/account/create")
    public BaseResponse<User> createAccount(@RequestHeader HttpHeaders header, @RequestBody Account account) {
        return this.accountService.createAccount(header, account);
    }

    /**
     * 删除用户
     * @param userId
     * @return message
     */
    @GetMapping("/admin/account/delete/{userId}")
    public BaseResponse<String> deleteAccount(@RequestHeader HttpHeaders header, @PathVariable String userId) {
        return this.accountService.deleteAccount(header, userId);
    }

    /**
     * 更新用户
     * @param account
     * @param userId
     * @return user
     */
    @PostMapping("/admin/account/update/{userId}")
    public BaseResponse<User> updateAccount(@RequestHeader HttpHeaders header, @RequestBody Account account, @PathVariable String userId) {
        return this.accountService.updateAccount(header, account, userId);
    }
    /**
     * 查询用户
     * @param userId
     * @return user
     */
    @GetMapping("/admin/account/query/{userId}")
    public BaseResponse<User> queryAccount(@RequestHeader HttpHeaders header, @PathVariable String userId) {
        return this.accountService.queryAccount(header, userId);
    }


}
