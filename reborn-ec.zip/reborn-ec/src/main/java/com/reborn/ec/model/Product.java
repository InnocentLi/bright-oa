package com.reborn.ec.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;
import org.hibernate.annotations.*;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Getter
@Setter
@ToString
@RequiredArgsConstructor
@DynamicUpdate(true)
@DynamicInsert
@Table(name = "product", schema = "rebornecdb")
public class Product {
    @Id
    @Column(name = "id")
    @GeneratedValue(generator="system-uuid")
    @GenericGenerator(name="system-uuid", strategy = "uuid")
    private String id;
    @Basic
    @Column(name = "name")
    private String name;
    @Basic
    @Column(name = "category_id")
    private String categoryId;
    @Basic
    @Column(name = "subcategory_id")
    private String subcategoryId;
    @Basic
    @Column(name = "shop_id")
    private String shopId;
    @Basic
    @Column(name = "price")
    private int price;
    @Basic
    @Column(name = "inventory_quantity")
    private int inventoryQuantity;
    //delete_flag: 0: not delete, 1: delete
    @Column(name = "delete_flag", insertable = false, columnDefinition = "TINYINT(1) NOT NULL DEFAULT 0")
    private byte deleteFlag;
    @Basic
    @Column(name = "created_at", insertable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @CreationTimestamp
    private Timestamp createdAt;
    @Basic
    @Column(name = "updated_at", insertable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    @UpdateTimestamp
    private Timestamp updatedAt;
    @Basic
    @Column(name = "image", columnDefinition = "DEFAULT NULL")
    private String image;
    @Basic
    @Column(name = "description", columnDefinition = "DEFAULT NULL")
    private String description;
    // 0: not selling, 1: selling, 2: sold out
    @Basic
    @Column(name = "status", columnDefinition = "TINYINT NOT NULL DEFAULT 0")
    private byte status;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Product product = (Product) o;
        return id != null && Objects.equals(id, product.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
