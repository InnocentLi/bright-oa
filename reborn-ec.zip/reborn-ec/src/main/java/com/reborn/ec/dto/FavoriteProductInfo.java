package com.reborn.ec.dto;

import com.reborn.ec.model.FavoriteProduct;

import lombok.Data;

@Data
public class FavoriteProductInfo {
    private FavoriteProduct favoriteProduct;
    private String shopName;
}
