package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.Address;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface AddressRepository extends JpaRepository<Address, String> {

    @Query("SELECT a FROM Address a WHERE a.id = :id AND a.deleteFlag = 0")
    Optional<Address> findById(String id);

    @Query("SELECT a FROM Address a WHERE a.deleteFlag = 0")
    List<Address> findAll();

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE Address SET postalCode = :postalCode, prefecture = :prefecture, ward = :ward, district = :district, buildingAndUnitNumber = :buildingAndUnitNumber WHERE id = :id")
    void setData(@Param("postalCode") String postalCode,@Param("prefecture") String prefecture,@Param("ward") String ward,@Param("district") String district,@Param("buildingAndUnitNumber") String buildingAndUnitNumber,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE Address SET postalCode = :postalCode WHERE id = :id")
    void setPostalCode(@Param("postalCode") String postalCode,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE Address SET prefecture = :prefecture WHERE id = :id")
    void setPrefecture(@Param("prefecture") String prefecture,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE Address SET ward = :ward WHERE id = :id")
    void setWard(@Param("ward") String ward,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE Address SET district = :district WHERE id = :id")
    void setDistrict(@Param("district") String district,@Param("id") String id);

    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE Address SET buildingAndUnitNumber = :buildingAndUnitNumber WHERE id = :id")
    void setBuildingAndUnitNumber(@Param("buildingAndUnitNumber") String buildingAndUnitNumber,@Param("id") String id);

    @Modifying
    @Query("UPDATE Address SET deleteFlag = 1 WHERE id = :id")
    void deleteAddress(@Param("id") String id);

    @Modifying
    @Query("UPDATE User c SET c.deleteFlag = :deleteFlag WHERE c.id = :userId")
    int updateAddress(@Param("userId") int userId, @Param("deleteFlag") String deleteFlag);

    @Query("SELECT a FROM Address a WHERE a.deleteFlag = 0 and a.entityId = :userId")
    List<Address> findByEntityId(String userId);
}