package com.reborn.ec.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.Address;
import com.reborn.ec.model.Advertisment;
import com.reborn.ec.model.Comment;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface CommentRepository extends JpaRepository<Comment, String>{

    @Query("SELECT c FROM Comment c WHERE c.deleteFlag = 0 and c.productID = :productID")
    List<Comment> findCommentsByProductID(@Param("productID")String productID);

}
