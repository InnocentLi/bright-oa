package com.reborn.ec.controller;

import com.reborn.ec.service.SalesTrackService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.SalesTrackReq;
import com.reborn.ec.dto.SalesTrackMonthReq;
import com.reborn.ec.dto.SalesTrackRes;
import com.reborn.ec.dto.SalesTrackTotalReq;

@RestController
public class SalesTrackController {
    
    private final SalesTrackService service;

    @Autowired
    public SalesTrackController(SalesTrackService service) {
        this.service = service;
    }
    // 週、月、年額
    @PostMapping("/salestrack/total")
    public BaseResponse<SalesTrackRes> monthTotal(@RequestHeader HttpHeaders header, @RequestBody SalesTrackMonthReq salesTrack) {
        return service.monthTotal(header, salesTrack);
    }

    // 月的累计金额
    @PostMapping("/salestrack/monthtotal")
    public BaseResponse<SalesTrackRes> totalByMonth(@RequestHeader HttpHeaders header, @RequestBody SalesTrackTotalReq salesTrack) {
        return service.totalByMonth(header, salesTrack);
    }

    // 売り上げ配列（２０まで）
    @PostMapping("/salestrack/top")
    public BaseResponse<SalesTrackRes> listTopSalesProduct(@RequestHeader HttpHeaders header, @RequestBody SalesTrackReq salesTrack) {
        return service.listTopSalesProduct(header, salesTrack);
    }
}
