package com.reborn.ec.dto;

import lombok.Data;

import java.util.List;

import com.reborn.ec.model.Address;
import com.reborn.ec.model.Order;
import com.reborn.ec.model.OrderDetail;
import com.reborn.ec.model.Payment;

@Data
public class OrderView {
    private Order order;
    private List<OrderDetail> orderDetails;
    private Address address;
    private Payment payment;
    private String username;
    private String shopName;
    private String shopBannerImage;
}
