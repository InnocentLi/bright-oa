package com.reborn.ec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.ChangeOrderStatusReq;
import com.reborn.ec.dto.OrderView;
import com.reborn.ec.model.Order;
import com.reborn.ec.service.OrderService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@RolesAllowed({"ROLE_SHOPOWNER"})
public class ShopOrderController {
    private final OrderService orderService;

    @Autowired
    public ShopOrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * 查看当前店铺所有订单
     * @param header
     * @return 订单信息
     */
    @GetMapping("/shop/order/list")
    public BaseResponse<List<OrderView>> getShopOrderList(@RequestHeader HttpHeaders header) {
        return orderService.getShopOrderList(header);
    }

   /**
     * 查询订单详情
     * @param header
     * @param orderId
     * @return 订单信息
     */
    @GetMapping("/shop/order/{orderId}")
    public BaseResponse<OrderView> getOrder(@RequestHeader HttpHeaders header, @PathVariable String orderId) {
        return orderService.getOrderDetails(header, orderId);
    }

    @PostMapping("/shop/order/update-status/{orderId}")
    public BaseResponse<Order> changeOrderStatus(@RequestHeader HttpHeaders header, @RequestBody ChangeOrderStatusReq status, @PathVariable String orderId) {
        return orderService.changeOrderStatus(header, status, orderId);
    }

}
