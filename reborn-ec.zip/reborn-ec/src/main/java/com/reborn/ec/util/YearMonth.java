package com.reborn.ec.util;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Calendar;

@Data
@NoArgsConstructor
public class YearMonth implements Comparable<YearMonth>{
    private String year;
    private String month;

    public YearMonth(String year, String month) {
        this.year = String.format("%04d", Integer.valueOf(year));
        this.month = String.format("%02d", Integer.valueOf(month));
    }

    public void addMonths(int n) {
        Calendar calendar = buildCalendar(this);
        calendar.add(Calendar.MONTH, n);
        this.setYear(String.valueOf(calendar.get(Calendar.YEAR)));
        this.setMonth(String.valueOf(calendar.get(Calendar.MONTH) + 1));
    }

    public int subtract(YearMonth other) {
        Calendar calendar = buildCalendar(this);
        Calendar calendarOther = buildCalendar(other);
        int count = 0;
        while (calendarOther.before(calendar)) {
            calendarOther.add(Calendar.MONTH, 1);
            count++;
        }
        return count;
    }

    @Override
    public int compareTo(YearMonth other) {
        Calendar calendar = buildCalendar(this);
        Calendar calendarOther = buildCalendar(other);
        return calendar.compareTo(calendarOther);
    }

    private Calendar buildCalendar(YearMonth yearMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, Integer.valueOf(yearMonth.getYear()));
        calendar.set(Calendar.MONTH, Integer.valueOf(yearMonth.getMonth()) - 1);
        return calendar;
    }

    public void setMonth(String month) {
        this.month = String.format("%02d", Integer.valueOf(month));
    }

    @Override
    public String toString() {
        return "YearMonth{" +
                "year='" + year + '\'' +
                ", month='" + month + '\'' +
                '}';
    }
}
