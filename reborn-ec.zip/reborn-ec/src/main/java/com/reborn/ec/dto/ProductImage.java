package com.reborn.ec.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ProductImage {
    private MultipartFile image;
    private String productId;
}
