package com.reborn.ec.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.OrderView;
import com.reborn.ec.dto.ShopInfo;
import com.reborn.ec.dto.ShopReturnReq;
import com.reborn.ec.dto.ShopView;
import com.reborn.ec.model.Order;
import com.reborn.ec.model.User;
import com.reborn.ec.service.OrderService;
import com.reborn.ec.service.ShopService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
public class ShopController {

    private final ShopService shopService;
    private final OrderService orderService;
    @Autowired
    public ShopController(ShopService shopService,OrderService orderService) {
        this.orderService = orderService;
        this.shopService = shopService;
    }


    /**
     * create shop
     * @param shopInfo
     * @return shop
     */
    @PostMapping("/admin/shop/create")
    @RolesAllowed("ROLE_ADMIN")
    public BaseResponse<ShopView> createShop(@RequestHeader HttpHeaders header, @RequestBody ShopInfo shopInfo) {
        return shopService.createShop(header, shopInfo);
    }

    /**
     * 上传店铺图片
     * @param header
     * @param shopImage 店铺图片信息(shopId, image)
     * @return 上传结果
     */
    @PostMapping(path="/admin/shop/image/upload/{shopId}", consumes = "multipart/form-data")
    @RolesAllowed("ROLE_ADMIN")
    public BaseResponse<String> uploadImage(@RequestHeader HttpHeaders header, @RequestPart MultipartFile shopImage, @PathVariable String shopId) {
        return shopService.uploadImage(header, shopImage, shopId);
    }

    /**
     * get shop by id
     * @param header
     * @param shopId
     * @return shop
     */
    @GetMapping("/shop/{shopId}")
    public BaseResponse<ShopView> getShopById(@RequestHeader HttpHeaders header, @PathVariable String shopId) {
        return shopService.getShopById(header, shopId);
    }

    /**
     * get shop list
     * @param header
     * @return ShopView list
     */
    @GetMapping("/shop/list")
    public BaseResponse<List<ShopView>> getShopList(@RequestHeader HttpHeaders header) {
        return shopService.getShopList(header);
    }

    /**
     * get shop owner list
     * @param header
     * @return ShopView list
     */
    @GetMapping("/admin/shopowner/list")
    @RolesAllowed({"ROLE_ADMIN"})
    public BaseResponse<List<User>> getShopOwnerList(@RequestHeader HttpHeaders header) {
        return shopService.getShopOwnerList(header);
    }

    /**
     * update shop
     * @param header
     * @param shopInfo
     * @param shopId
     * @return shopView
     */
    @PostMapping("/shop/update/{shopId}")
    @RolesAllowed({"ROLE_ADMIN", "ROLE_SHOPOWNER"})
    public BaseResponse<ShopView> updateShop(@RequestHeader HttpHeaders header, @RequestBody ShopInfo shopInfo, @PathVariable String shopId) {
        return shopService.updateShop(header, shopInfo, shopId);
    }


    /**
     * delete shop
     * @param header
     * @param shopId
     * @return message
     */
    @PostMapping("/admin/shop/delete/{shopId}")
    @RolesAllowed({"ROLE_ADMIN"})
    public BaseResponse<String> deleteShop(@RequestHeader HttpHeaders header, @PathVariable String shopId) {
        return shopService.deleteShop(header, shopId);
    }


    /**
     * get my shop
     * @param header
     * @return shop
     * @comment shop owner can get his/her shop
     */
    @GetMapping("/shop/my-shop")
    @RolesAllowed({"ROLE_SHOPOWNER"})
    public BaseResponse<ShopView> getShop(@RequestHeader HttpHeaders header) {
        return shopService.getMyShop(header);
    }
    //currently not in use 
    @PostMapping("/order/shop/return")
    @RolesAllowed({"ROLE_SHOPOWNER"})
    public BaseResponse<Order> confirmReturnOrder(@RequestHeader HttpHeaders header,@RequestBody ShopReturnReq returnReq) {
        return orderService.confirmReturnOrder(header, returnReq);
    }

    @GetMapping("/order/shop/return")
    @RolesAllowed({"ROLE_SHOPOWNER"})
    public BaseResponse<List<OrderView>> getShopReturnList(@RequestHeader HttpHeaders header) {
        return orderService.getShopReturnList(header);
    }
}
