package com.reborn.ec.util;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.beans.PropertyDescriptor;
import java.util.HashSet;
import java.util.Set;

public class Common {
    public static String[] getNullPropertyNames(Object source) {
        BeanWrapper src = new BeanWrapperImpl(source);
        PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> emptyNames = new HashSet<>();

        for (PropertyDescriptor pd : pds) {
            //check if value of this property is null then add it to the collection
            Object srcValue = src.getPropertyValue(pd.getName());
            if (srcValue == null){
                emptyNames.add(pd.getName());
            }
        }

        String[] result = new String[emptyNames.size()];
        return emptyNames.toArray(result);
    }
    public static String randomPassword() { // random password with length 10 and alphanumeric characters and special characters
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            int index = (int) (Math.random() * 3);
            switch (index) {
                case 0:
                    sb.append((char) (Math.random() * 26 + 'a'));
                    break;
                case 1:
                    sb.append((char) (Math.random() * 26 + 'A'));
                    break;
                case 2:
                    sb.append((char) (Math.random() * 10 + '0'));
                    break;
            }
        }

        // add special characters randomly
        int index = (int) (Math.random() * 3);
        switch (index) {
            case 0:
                sb.append('!');
                break;
            case 1:
                sb.append('@');
                break;
            case 2:
                sb.append('#');
                break;
        }
        return sb.toString();
    }
}
