package com.reborn.ec.dto;

import lombok.Data;

@Data
public class SalesTrackMonthReq {
    String shopID;
    String selectedDate;
    String type; 
}
