package com.reborn.ec.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.AdvertismentReq;
import com.reborn.ec.dto.AdvertismentRes;
import com.reborn.ec.service.AdvertiseService;

@RestController
public class AdvertiseContorller {

    private final AdvertiseService service;

    @Autowired
    public AdvertiseContorller(AdvertiseService service) {
        this.service = service;
    }
 
    // 宣伝展示：新規
    @PostMapping("/advertisment/create")
    public BaseResponse<AdvertismentRes> createAdvertisment(@RequestHeader HttpHeaders header, @RequestBody AdvertismentReq advertisment) {
        return service.createAdvertisment(header, advertisment);
    }

    // 宣伝展示：変更
    @PostMapping("/advertisment/change")
    public BaseResponse<AdvertismentRes> changeAdvertisment(@RequestHeader HttpHeaders header, @RequestBody AdvertismentReq advertisment) {
        return service.changeAdvertisment(header, advertisment);
    }

    // 宣伝展示：削除
    @PostMapping("/advertisment/delete")
    public BaseResponse<AdvertismentRes> deleteAdvertisment(@RequestHeader HttpHeaders header, @RequestBody AdvertismentReq advertisment) {
        return service.deleteAdvertisment(header, advertisment);
    }

    // 宣伝展示：list
    @PostMapping("/advertisment/list")
    public BaseResponse<List<AdvertismentRes>> listAdvertisment(@RequestHeader HttpHeaders header, @RequestBody AdvertismentReq advertisment) {
        return service.listAdvertisment(header, advertisment);
    }

   @PostMapping(path="/advertisment/image/upload/{advertismentID}", consumes = "multipart/form-data")
    public BaseResponse<String> uploadAdvertismentCoverImage(@RequestHeader HttpHeaders header, @RequestPart MultipartFile image, @PathVariable String advertismentID) {
        return service.uploadAdvertismentCoverImage(header, image, advertismentID);
    }
}
