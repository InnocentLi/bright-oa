package com.reborn.ec.dto;

import lombok.Data;

@Data
public class ChangeOrderStatusReq {
    private final byte statusCode;
    private final String shopComment;
}
