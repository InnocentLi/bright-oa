package com.reborn.ec.dto;


import lombok.Data;

@Data
public class UserView {
    private String username;
    private String token;
    private String role;
    private String shopId;
    private String shopName;

    public UserView(String username, String token, String role,String shopId,String shopName) {
        this.username = username;
        this.token = token;
        this.role = role;
        this.shopId = shopId;
        this.shopName = shopName;
    }
}
