package com.reborn.ec.dto;

import lombok.Data;

@Data
public class ShopInfo {
    private String name;
    private String phone;
    private String description;
    private String companyId;
    private String addressId;
    private String ownerEmail;
    private String userId;
}
