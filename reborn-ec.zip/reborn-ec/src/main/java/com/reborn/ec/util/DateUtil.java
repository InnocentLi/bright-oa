package com.reborn.ec.util;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
    public static YearMonth parseYearMonth(String yearMonth) throws ParseException {
        Date date = new SimpleDateFormat("yyyy-MM").parse(yearMonth);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        String year = String.valueOf(calendar.get(Calendar.YEAR));
        String month = String.format("%02d",calendar.get(Calendar.MONTH) + 1);
        return new YearMonth(year, month);
    }
    public static Calendar parseCalendar(String dateStr) throws ParseException {
        Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }

    public static Date parseDate(String dateStr) throws ParseException {
        Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        return date;
    }
}
