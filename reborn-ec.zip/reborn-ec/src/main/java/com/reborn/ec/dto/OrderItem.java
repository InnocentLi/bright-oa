package com.reborn.ec.dto;

import lombok.Data;

@Data
public class OrderItem {
    private String productId;
    private Integer quantity;
}
