package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.reborn.ec.model.Advertisment;


import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
@Transactional
@Repository
public interface AdvertiseRepository extends JpaRepository<Advertisment, String>{

    @Query("SELECT adv FROM Advertisment adv WHERE adv.deleteFlag = 0")
    List<Advertisment> findAll();

    @Query("SELECT adv FROM Advertisment adv WHERE adv.id = :id AND adv.deleteFlag = 0")
    Optional<Advertisment> findById(@Param("id") String Id);

    @Modifying
    @Query("UPDATE Advertisment adv SET adv.deleteFlag = 1 WHERE adv.id = :advertismentID")
    int deleteAdvertismentByID(@Param("advertismentID") String advertismentID);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE Advertisment adv SET adv.coverImage = :imageUrl WHERE adv.id = :id")
    void updateImage(@Param("id") String id, @Param("imageUrl") String imageUrl);
}
