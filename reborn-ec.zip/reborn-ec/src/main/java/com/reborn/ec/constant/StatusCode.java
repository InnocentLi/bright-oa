package com.reborn.ec.constant;

import lombok.Data;

@Data
public class StatusCode {
    public static final String userUnauthed ="4010";
    public static final String userDisabled ="4011";
    public static final String userLocked ="4012";
    public static final String deletedFailed ="4013";
    public static final String failed ="4014";
}
