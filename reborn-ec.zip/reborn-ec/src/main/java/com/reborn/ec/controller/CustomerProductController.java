package com.reborn.ec.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import com.reborn.ec.common.BaseResponse;
import com.reborn.ec.dto.ProductInfo;
import com.reborn.ec.model.Product;
import com.reborn.ec.service.ProductService;

import javax.annotation.security.RolesAllowed;
import java.util.List;

@RestController
@RolesAllowed({"ROLE_CUSTOMER", "ROLE_ADMIN"})
public class CustomerProductController {
    private final ProductService productService;

    @Autowired
    public CustomerProductController(ProductService productService) {
        this.productService = productService;
    }

    /**
     * Get all products
     * @param header
     * @return BaseResponse<List<Product>>
     */
    @GetMapping("/products")
    public BaseResponse<List<Product>> getAllProducts(@RequestHeader HttpHeaders header) {
        return productService.getAllProducts(header);
    }

    /**
     * 获取指定店铺所有商品
     * @param shopId 店铺 id
     * @return 商品列表
     */
    @GetMapping("/product/list/{shopId}")
    public BaseResponse<List<Product>> getShopProductList(@RequestHeader HttpHeaders header, @PathVariable String shopId) {
        return productService.getProducts(header, shopId);
    }

    /**
     * 获取商品详情
     * @param productId 商品 id
     * @return 商品详情
     */
    @GetMapping("/product/detail/{productId}")
    public BaseResponse<ProductInfo> getProductDetail(@RequestHeader HttpHeaders header, @PathVariable String productId) {
        return productService.getProductDetail(header, productId);
    }


    /**
     * 查询商品
     * @param productName 商品名
     * @return 与搜索字段匹配的商品
     * @Comment 用户用商品名进行模糊查询
     */
    @GetMapping("/products/search")
    public BaseResponse<List<Product>> getSearchedProducts(@RequestHeader HttpHeaders header, @RequestParam String productName) {
        return productService.getSearchedProducts(header, productName);
    }

}
