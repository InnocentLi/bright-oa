package com.reborn.ec.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.reborn.ec.model.ProductSubcategory;

public interface ProductSubcategoryRepository extends JpaRepository<ProductSubcategory, String> {

}